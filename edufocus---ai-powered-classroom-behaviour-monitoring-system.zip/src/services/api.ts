import { Student, TeacherMember, ClassroomRoom, DetectionRecord } from '../types';

const API_BASE = '/api';

interface ApiResponse<T> {
  success: boolean;
  data: T;
  source?: string;
  message?: string;
}

export const api = {
  // Health
  checkHealth: async () => {
    try {
      const res = await fetch(`${API_BASE}/health`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch {
      return null;
    }
  },

  // Students
  getStudents: async (classroomId?: string): Promise<Student[] | null> => {
    try {
      const url = classroomId ? `${API_BASE}/students?classroomId=${encodeURIComponent(classroomId)}` : `${API_BASE}/students`;
      const res = await fetch(url);
      if (!res.ok) return null;
      const json: ApiResponse<any[]> = await res.json();
      if (!json.success || !Array.isArray(json.data)) return null;
      
      // Map to frontend Student type
      return json.data.map(item => ({
        id: item._id || item.id || item.studentId,
        studentId: item.studentId,
        registerNumber: item.registerNumber,
        name: item.name,
        email: item.email,
        assignedSeat: item.seatNumber || item.assignedSeat,
        classroom: item.classroomId || item.classroom,
        status: item.status,
        detectionCount: item.detectionCount || 0,
        notes: item.notes || ''
      }));
    } catch {
      return null;
    }
  },

  createStudent: async (studentData: Partial<Student>): Promise<Student | null> => {
    try {
      const payload = {
        studentId: studentData.studentId,
        registerNumber: studentData.registerNumber,
        name: studentData.name,
        email: studentData.email,
        seatNumber: studentData.assignedSeat,
        classroomId: studentData.classroom,
        status: studentData.status || 'Present',
        detectionCount: studentData.detectionCount || 0,
      };
      const res = await fetch(`${API_BASE}/students`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) return null;
      const json = await res.json();
      if (!json.success || !json.data) return null;
      const item = json.data;
      return {
        id: item._id || item.id || item.studentId,
        studentId: item.studentId,
        registerNumber: item.registerNumber,
        name: item.name,
        email: item.email,
        assignedSeat: item.seatNumber,
        classroom: item.classroomId,
        status: item.status,
        detectionCount: item.detectionCount || 0
      };
    } catch {
      return null;
    }
  },

  updateStudent: async (studentId: string, updates: Partial<Student>): Promise<boolean> => {
    try {
      const payload: any = {};
      if (updates.name) payload.name = updates.name;
      if (updates.email) payload.email = updates.email;
      if (updates.assignedSeat) payload.seatNumber = updates.assignedSeat;
      if (updates.classroom) payload.classroomId = updates.classroom;
      if (updates.status) payload.status = updates.status;
      if (updates.detectionCount !== undefined) payload.detectionCount = updates.detectionCount;

      const res = await fetch(`${API_BASE}/students/${encodeURIComponent(studentId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  deleteStudent: async (studentId: string): Promise<boolean> => {
    try {
      const res = await fetch(`${API_BASE}/students/${encodeURIComponent(studentId)}`, {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // Teachers
  getTeachers: async (): Promise<TeacherMember[] | null> => {
    try {
      const res = await fetch(`${API_BASE}/teachers`);
      if (!res.ok) return null;
      const json: ApiResponse<any[]> = await res.json();
      if (!json.success || !Array.isArray(json.data)) return null;
      return json.data.map((item: any) => ({
        id: item._id || item.id || item.teacherId,
        empId: item.teacherId,
        name: item.name,
        email: item.email,
        department: item.department,
        assignedClassroom: item.assignedClassroom,
        status: item.status,
      }));
    } catch {
      return null;
    }
  },

  createTeacher: async (teacher: Partial<TeacherMember>): Promise<TeacherMember | null> => {
    try {
      const res = await fetch(`${API_BASE}/teachers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teacherId: teacher.empId,
          name: teacher.name,
          email: teacher.email,
          department: teacher.department,
          assignedClassroom: teacher.assignedClassroom,
          status: teacher.status || 'Active',
        }),
      });
      if (!res.ok) return null;
      const json = await res.json();
      if (!json.success || !json.data) return null;
      const item = json.data;
      return {
        id: item._id || item.id || item.teacherId,
        empId: item.teacherId,
        name: item.name,
        email: item.email,
        department: item.department,
        assignedClassroom: item.assignedClassroom,
        status: item.status,
      };
    } catch {
      return null;
    }
  },

  deleteTeacher: async (teacherId: string): Promise<boolean> => {
    try {
      const res = await fetch(`${API_BASE}/teachers/${encodeURIComponent(teacherId)}`, {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // Classrooms
  getClassrooms: async (): Promise<ClassroomRoom[] | null> => {
    try {
      const res = await fetch(`${API_BASE}/classrooms`);
      if (!res.ok) return null;
      const json: ApiResponse<any[]> = await res.json();
      if (!json.success || !Array.isArray(json.data)) return null;
      return json.data.map((item: any) => ({
        id: item._id || item.id || item.classroomId,
        classroomId: item.classroomId,
        classroomName: item.classroomName,
        building: item.building,
        floor: item.floor,
        capacity: item.capacity,
        rows: item.rows || 4,
        columns: item.columns || 5,
        assignedTeacher: item.assignedTeacher || '',
        studentsCount: item.capacity || 60,
        cameraType: item.cameraType || 'Laptop Webcam',
        cameraStatus: item.cameraStatus || 'Not Connected',
      }));
    } catch {
      return null;
    }
  },

  // Detections
  getDetections: async (classroomId?: string): Promise<DetectionRecord[] | null> => {
    try {
      const url = classroomId ? `${API_BASE}/detections?classroomId=${encodeURIComponent(classroomId)}` : `${API_BASE}/detections`;
      const res = await fetch(url);
      if (!res.ok) return null;
      const json: ApiResponse<any[]> = await res.json();
      if (!json.success || !Array.isArray(json.data)) return null;
      return json.data.map((item: any) => {
        const dateObj = item.detectedAt ? new Date(item.detectedAt) : new Date();
        return {
          id: item.detectionId || item._id || item.id,
          date: dateObj.toISOString().split('T')[0],
          time: dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          studentId: item.studentId,
          studentName: item.studentName,
          seat: item.seatNumber,
          classroom: item.classroomId,
          detectionType: item.detectionType,
          behaviour: item.behaviour || 'Other',
          confidence: item.confidence || '90%',
          status: 'Flagged',
          source: item.source || 'Laptop Webcam',
        };
      });
    } catch {
      return null;
    }
  },
};
