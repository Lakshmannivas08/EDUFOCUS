import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Square, 
  ChevronRight, 
  LogOut, 
  BookOpen,
  Building
} from 'lucide-react';
import { PageType, UserProfile } from '../../types';

interface TopHeaderProps {
  activePage: PageType;
  user: UserProfile;
  isSessionActive: boolean;
  onToggleSession: () => void;
  onLogout: () => void;
  activeCourse: string;
  onChangeCourse: (course: string) => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  activePage,
  user,
  isSessionActive,
  onToggleSession,
  onLogout,
  activeCourse,
  onChangeCourse
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [sessionDurationSec, setSessionDurationSec] = useState<number>(1425); // ~23m 45s

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!isSessionActive) return;
    const interval = setInterval(() => {
      setSessionDurationSec(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isSessionActive]);

  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getPageTitle = (page: PageType) => {
    switch (page) {
      case 'dashboard': return user.role === 'admin' ? 'Admin Control Dashboard' : 'Teacher Dashboard';
      case 'detection': return 'Detection Monitoring (Webcam View)';
      case 'classroom': return 'Classroom Layout & Seating';
      case 'students': return 'Student Management';
      case 'reports': return 'Behavioural Reports & Analytics';
      case 'settings': return 'Teacher Calibration Settings';
      case 'teachers': return 'Faculty & Teacher Management';
      case 'classrooms': return 'Classrooms & Physical Labs';
      case 'detection-records': return 'System Detection Records';
      case 'system-settings': return 'Institutional System Settings';
      default: return 'Workspace';
    }
  };

  return (
    <header className="h-16 bg-[#0f131a] border-b border-[#1a2232] px-6 flex items-center justify-between shrink-0">
      {/* Zone 1: Breadcrumbs & Page Identifier */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-slate-400">
          {user.role === 'admin' ? 'Administration' : 'Classroom Lab'}
        </span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-slate-200 font-medium">{getPageTitle(activePage)}</span>
      </div>

      {/* Zone 2: Course Selector or System Node & Clock */}
      <div className="flex items-center gap-4">
        {user.role === 'teacher' ? (
          <div className="flex items-center gap-2 bg-[#141a24] border border-[#20293a] px-3 py-1.5 rounded">
            <BookOpen className="w-3.5 h-3.5 text-teal-400" />
            <select 
              value={activeCourse} 
              onChange={(e) => onChangeCourse(e.target.value)}
              className="bg-transparent text-xs text-slate-200 outline-none cursor-pointer pr-1"
            >
              <option value="CS402" className="bg-[#141a24] text-slate-200">CS402: Computer Vision Lab (Room 302)</option>
              <option value="CS408" className="bg-[#141a24] text-slate-200">CS408: Embedded Systems (Room 204)</option>
              <option value="CS310" className="bg-[#141a24] text-slate-200">CS310: Signal Processing (Hall B)</option>
            </select>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-[#141a24] border border-[#20293a] px-3 py-1.5 rounded text-xs text-slate-200">
            <Building className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-medium">System Domain: All Classrooms & Sensors</span>
          </div>
        )}

        {/* Telemetry Clock */}
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400 px-2.5 py-1.5 bg-[#121620] border border-[#1d2433] rounded">
          <span className="text-slate-400">SYS</span>
          <span className="text-slate-200 tabular-nums">{currentTime || '10:14:02'}</span>
          {user.role === 'teacher' && (
            <>
              <span className="text-slate-400">|</span>
              <span className="text-teal-400 tabular-nums">REC {formatTimer(sessionDurationSec)}</span>
            </>
          )}
        </div>
      </div>

      {/* Zone 3: Session Controls & User Profile */}
      <div className="flex items-center gap-3">
        {/* Quick Session Start/Stop Toggle (For Teacher) */}
        {user.role === 'teacher' && (
          <button
            onClick={onToggleSession}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
              isSessionActive 
                ? 'bg-amber-950/60 text-amber-300 border border-amber-700/60 hover:bg-amber-900/60' 
                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-700/60 hover:bg-emerald-900/60'
            }`}
            title={isSessionActive ? 'Pause current monitoring session' : 'Begin monitoring session'}
          >
            {isSessionActive ? (
              <>
                <Square className="w-3 h-3 fill-amber-400" />
                <span>Pause Monitor</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 fill-emerald-400" />
                <span>Resume Monitor</span>
              </>
            )}
          </button>
        )}

        {/* User Card */}
        <div className="flex items-center gap-2 pl-2 border-l border-[#1f2736]">
          <div className="w-7 h-7 rounded bg-[#162329] border border-teal-600/40 text-teal-300 flex items-center justify-center text-xs font-semibold">
            {user.avatarInitials}
          </div>
          <div className="hidden lg:block text-left">
            <div className="text-xs font-medium text-slate-200">{user.name}</div>
            <div className="text-[10px] text-slate-400 uppercase font-mono">
              {user.role === 'admin' ? 'Administrator' : 'Teacher'}
            </div>
          </div>
          <button
            onClick={onLogout}
            className="p-1.5 rounded hover:bg-[#1b2230] text-slate-400 hover:text-slate-200 transition-colors ml-1 cursor-pointer"
            title="Logout to Login Screen"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
