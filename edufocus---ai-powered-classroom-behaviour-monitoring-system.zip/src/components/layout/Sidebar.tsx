import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Grid3X3, 
  ScanEye, 
  BarChart3, 
  Settings, 
  GraduationCap, 
  ShieldCheck,
  CircleDot,
  Building2,
  FileSpreadsheet,
  LogOut,
  Sliders
} from 'lucide-react';
import { PageType, UserRole } from '../../types';

interface SidebarProps {
  role: UserRole;
  activePage: PageType;
  onNavigate: (page: PageType) => void;
  isSessionActive: boolean;
  onLogout: () => void;
}

interface NavItem {
  id: PageType;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  role,
  activePage, 
  onNavigate, 
  isSessionActive,
  onLogout
}) => {
  const teacherNavItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'classroom', label: 'Classroom', icon: Grid3X3 },
    { id: 'detection', label: 'Detection Monitoring', icon: ScanEye, badge: isSessionActive ? 'LIVE' : undefined },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const adminNavItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'teachers', label: 'Teachers', icon: GraduationCap },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'classrooms', label: 'Classrooms', icon: Building2 },
    { id: 'detection-records', label: 'Detection Records', icon: ScanEye },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'system-settings', label: 'System Settings', icon: Sliders },
  ];

  const navItems: NavItem[] = role === 'admin' ? adminNavItems : teacherNavItems;

  return (
    <aside className="w-64 bg-[#0d1017] border-r border-[#1a2232] flex flex-col h-screen shrink-0 select-none">
      {/* Institutional Brand Zone */}
      <div className="p-5 border-b border-[#1a2232]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-md bg-[#132328] border border-[#0d9488]/40 flex items-center justify-center text-[#14b8a6]">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="text-base font-semibold tracking-wide text-slate-100 flex items-center gap-1.5">
              EDUFOCUS
            </div>
            <p className="text-[11px] text-slate-400 font-normal">
              AI Classroom Telemetry
            </p>
          </div>
        </div>
      </div>

      {/* Role & Status Banner */}
      <div className="mx-3 my-3 p-2.5 rounded border border-[#1a2333] bg-[#111622] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CircleDot className={`w-3.5 h-3.5 ${role === 'admin' ? 'text-cyan-400' : isSessionActive ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
          <span className="text-xs text-slate-300">
            {role === 'admin' ? 'Administrator' : isSessionActive ? 'Monitoring Active' : 'Session Standby'}
          </span>
        </div>
        <span className="text-[10px] text-slate-400 font-mono px-1.5 py-0.5 rounded bg-[#16202c]">
          {role === 'admin' ? 'SYS-ADMIN' : 'Lab 302'}
        </span>
      </div>

      {/* Primary Navigation List */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        <div className="text-[11px] font-medium text-slate-400 px-3 py-1.5 uppercase tracking-wider">
          {role === 'admin' ? 'Admin Navigation' : 'Teacher Navigation'}
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-medium transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#13242c] text-teal-300 border-l-2 border-teal-500 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#121722]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-teal-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Logout Action & Footer Status */}
      <div className="p-3 border-t border-[#1a2232] bg-[#0b0e14] space-y-2">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded text-xs text-slate-400 hover:text-rose-300 hover:bg-rose-950/20 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4 text-slate-400 hover:text-rose-400" />
          <span>Logout</span>
        </button>

        <div className="pt-2 border-t border-[#161d28] flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
            <span>Prototype v1.0</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Webcam Mode</span>
        </div>
      </div>
    </aside>
  );
};
