/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  PageType, 
  Student, 
  DetectionRecord, 
  UserProfile, 
  UserRole,
  TeacherMember,
  ClassroomRoom,
  SystemActivity
} from './types';
import { 
  initialStudents, 
  initialDetectionRecords, 
  demoTeacherUser, 
  demoAdminUser,
  initialTeachers,
  initialClassrooms,
  initialSystemActivities
} from './data/mockData';
import { api } from './services/api';
import { Sidebar } from './components/layout/Sidebar';
import { TopHeader } from './components/layout/TopHeader';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminTeachersPage } from './pages/AdminTeachersPage';
import { AdminClassroomsPage } from './pages/AdminClassroomsPage';
import { AdminDetectionRecordsPage } from './pages/AdminDetectionRecordsPage';
import { StudentManagementPage } from './pages/StudentManagementPage';
import { ClassroomLayoutPage } from './pages/ClassroomLayoutPage';
import { DetectionMonitoringPage } from './pages/DetectionMonitoringPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [user, setUser] = useState<UserProfile>(demoTeacherUser);
  const [activePage, setActivePage] = useState<PageType>('dashboard');
  
  // Classroom telemetry states
  const [isSessionActive, setIsSessionActive] = useState<boolean>(true);
  const [activeCourse, setActiveCourse] = useState<string>('CS402');
  
  // Mock data state collections
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [teachers, setTeachers] = useState<TeacherMember[]>(initialTeachers);
  const [classrooms, setClassrooms] = useState<ClassroomRoom[]>(initialClassrooms);
  const [records, setRecords] = useState<DetectionRecord[]>(initialDetectionRecords);
  const [systemActivities, setSystemActivities] = useState<SystemActivity[]>(initialSystemActivities);

  // Initial load from backend API if available
  useEffect(() => {
    let isMounted = true;
    const loadBackendData = async () => {
      try {
        const [apiStudents, apiTeachers, apiClassrooms, apiDetections] = await Promise.all([
          api.getStudents(),
          api.getTeachers(),
          api.getClassrooms(),
          api.getDetections(),
        ]);
        if (!isMounted) return;
        if (apiStudents && apiStudents.length > 0) setStudents(apiStudents);
        if (apiTeachers && apiTeachers.length > 0) setTeachers(apiTeachers);
        if (apiClassrooms && apiClassrooms.length > 0) setClassrooms(apiClassrooms);
        if (apiDetections && apiDetections.length > 0) setRecords(apiDetections);
      } catch (err) {
        console.warn('Backend API connection check: using local state fallback', err);
      }
    };
    loadBackendData();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleLogin = (role: UserRole) => {
    setIsAuthenticated(true);
    if (role === 'admin') {
      setUser(demoAdminUser);
    } else {
      setUser(demoTeacherUser);
    }
    setActivePage('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setActivePage('dashboard');
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.id === updatedStudent.id ? updatedStudent : s));
    api.updateStudent(updatedStudent.studentId || updatedStudent.id, updatedStudent);
  };

  const handleAddStudent = (newStudent: Student) => {
    setStudents(prev => [newStudent, ...prev]);
    api.createStudent(newStudent);
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents(prev => prev.filter(s => s.id !== studentId && s.studentId !== studentId));
    api.deleteStudent(studentId);
  };

  const handleAddTeacher = (newTeacher: TeacherMember) => {
    setTeachers(prev => [newTeacher, ...prev]);
    api.createTeacher(newTeacher);
    setSystemActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: 'Just now',
        actor: user.name,
        action: `Added new faculty teacher ${newTeacher.name} (${newTeacher.empId})`,
        type: 'user_add',
      },
      ...prev
    ]);
  };

  const handleUpdateTeacher = (updatedTeacher: TeacherMember) => {
    setTeachers(prev => prev.map(t => t.id === updatedTeacher.id ? updatedTeacher : t));
  };

  const handleDeleteTeacher = (teacherId: string) => {
    setTeachers(prev => prev.filter(t => t.id !== teacherId && t.empId !== teacherId));
    api.deleteTeacher(teacherId);
  };

  const handleAddClassroom = (newRoom: ClassroomRoom) => {
    setClassrooms(prev => [newRoom, ...prev]);
    setSystemActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: 'Just now',
        actor: user.name,
        action: `Registered classroom facility ${newRoom.classroomName} (${newRoom.classroomId})`,
        type: 'calibration',
      },
      ...prev
    ]);
  };

  const handleUpdateClassroom = (updatedRoom: ClassroomRoom) => {
    setClassrooms(prev => prev.map(c => c.id === updatedRoom.id ? updatedRoom : c));
  };

  const handleDeleteClassroom = (classroomId: string) => {
    setClassrooms(prev => prev.filter(c => c.id !== classroomId && c.classroomId !== classroomId));
  };

  const handleToggleSession = () => {
    setIsSessionActive(prev => !prev);
  };

  // If not logged in, render the login page
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0a0d13] text-[#e2e8f0]">
      {/* Left Navigation Sidebar */}
      <Sidebar
        role={user.role}
        activePage={activePage}
        onNavigate={setActivePage}
        isSessionActive={isSessionActive}
        onLogout={handleLogout}
      />

      {/* Main Workspace Canvas */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Top Header */}
        <TopHeader
          activePage={activePage}
          user={user}
          isSessionActive={isSessionActive}
          onToggleSession={handleToggleSession}
          onLogout={handleLogout}
          activeCourse={activeCourse}
          onChangeCourse={setActiveCourse}
        />

        {/* Dynamic Page Content Viewport */}
        <main className="flex-1 overflow-y-auto bg-[#0c1017]">
          {/* TEACHER DASHBOARD & VIEWS */}
          {user.role === 'teacher' && (
            <>
              {activePage === 'dashboard' && (
                <DashboardPage
                  onNavigate={setActivePage}
                  students={students}
                  records={records}
                />
              )}

              {activePage === 'students' && (
                <StudentManagementPage
                  students={students}
                  onUpdateStudent={handleUpdateStudent}
                  onAddStudent={handleAddStudent}
                  onDeleteStudent={handleDeleteStudent}
                />
              )}

              {activePage === 'classroom' && (
                <ClassroomLayoutPage
                  students={students}
                  onNavigate={setActivePage}
                />
              )}

              {activePage === 'detection' && (
                <DetectionMonitoringPage
                  records={records}
                />
              )}

              {activePage === 'reports' && (
                <ReportsPage
                  records={records}
                />
              )}

              {activePage === 'settings' && (
                <SettingsPage />
              )}
            </>
          )}

          {/* ADMIN DASHBOARD & VIEWS */}
          {user.role === 'admin' && (
            <>
              {activePage === 'dashboard' && (
                <AdminDashboardPage
                  onNavigate={setActivePage}
                  teachers={teachers}
                  classrooms={classrooms}
                  studentsCount={students.length}
                  records={records}
                  systemActivities={systemActivities}
                />
              )}

              {activePage === 'teachers' && (
                <AdminTeachersPage
                  teachers={teachers}
                  onAddTeacher={handleAddTeacher}
                  onUpdateTeacher={handleUpdateTeacher}
                  onDeleteTeacher={handleDeleteTeacher}
                />
              )}

              {activePage === 'students' && (
                <StudentManagementPage
                  students={students}
                  onUpdateStudent={handleUpdateStudent}
                  onAddStudent={handleAddStudent}
                  onDeleteStudent={handleDeleteStudent}
                />
              )}

              {activePage === 'classrooms' && (
                <AdminClassroomsPage
                  classrooms={classrooms}
                  onAddClassroom={handleAddClassroom}
                  onUpdateClassroom={handleUpdateClassroom}
                  onDeleteClassroom={handleDeleteClassroom}
                />
              )}

              {activePage === 'detection-records' && (
                <AdminDetectionRecordsPage
                  records={records}
                />
              )}

              {activePage === 'reports' && (
                <ReportsPage
                  records={records}
                />
              )}

              {activePage === 'system-settings' && (
                <SettingsPage />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
