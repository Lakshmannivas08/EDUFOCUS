import React, { useState } from 'react';
import { 
  Camera, 
  Play, 
  Square, 
  VideoOff, 
  Clock, 
  Activity, 
  Info,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { DetectionRecord } from '../types';

interface DetectionMonitoringPageProps {
  records: DetectionRecord[];
}

export const DetectionMonitoringPage: React.FC<DetectionMonitoringPageProps> = ({
  records
}) => {
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraFeedback, setCameraFeedback] = useState<string | null>(null);

  const handleStartCamera = () => {
    setCameraFeedback('Notice: Live camera hardware access is in development. Running in simulated standby mode.');
    setIsCameraActive(true);
  };

  const handleStopCamera = () => {
    setIsCameraActive(false);
    setCameraFeedback(null);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Detection Monitoring</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Laptop Optical Sensor Interface · Classroom: <span className="text-teal-400 font-medium">CSE-A</span>
          </p>
        </div>

        {/* Start / Stop Camera Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleStartCamera}
            disabled={isCameraActive}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isCameraActive 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-teal-600 hover:bg-teal-500 text-white'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Start Camera</span>
          </button>

          <button
            onClick={handleStopCamera}
            disabled={!isCameraActive}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              !isCameraActive 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-rose-950/70 border border-rose-700/60 text-rose-300 hover:bg-rose-900/70'
            }`}
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Stop Camera</span>
          </button>
        </div>
      </div>

      {cameraFeedback && (
        <div className="p-3 bg-[#171f28] border border-cyan-800/50 rounded text-xs text-cyan-200 flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{cameraFeedback}</span>
        </div>
      )}

      {/* Main Grid: Large Camera Preview Panel + Right-side Detection Information Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Large Camera Preview Panel */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative aspect-video bg-[#0a0d13] border-2 border-[#1c2435] rounded-lg overflow-hidden flex flex-col items-center justify-center select-none shadow-2xl">
            {/* Subtle Matrix Background */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#14b8a6_1px,transparent_1px)] [background-size:24px_24px]"></div>

            {/* Corner Crosshairs */}
            <div className="absolute top-4 left-4 w-4 h-4 border-t-2 border-l-2 border-teal-500/60"></div>
            <div className="absolute top-4 right-4 w-4 h-4 border-t-2 border-r-2 border-teal-500/60"></div>
            <div className="absolute bottom-4 left-4 w-4 h-4 border-b-2 border-l-2 border-teal-500/60"></div>
            <div className="absolute bottom-4 right-4 w-4 h-4 border-b-2 border-r-2 border-teal-500/60"></div>

            {/* Top Bar Overlay */}
            <div className="absolute top-3 left-4 right-4 flex items-center justify-between text-xs font-mono text-slate-400 pointer-events-none">
              <span className="bg-black/70 px-2 py-0.5 rounded border border-slate-800">
                LAPTOP WEBCAM
              </span>
              <span className="bg-black/70 px-2 py-0.5 rounded border border-slate-800 text-rose-400">
                Camera Status: {isCameraActive ? 'SIMULATED STANDBY' : 'NOT CONNECTED'}
              </span>
            </div>

            {/* Central Display Box */}
            <div className="z-10 text-center max-w-md px-6 py-5 bg-[#0d121c]/90 backdrop-blur-xs border border-[#1b2538] rounded-lg space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#151c27] border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
                <VideoOff className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-100">LAPTOP WEBCAM</h2>
                <div className="text-xs font-mono text-rose-400 font-semibold mt-1">
                  Camera Status: {isCameraActive ? 'SIMULATED STANDBY' : 'NOT CONNECTED'}
                </div>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Live camera and AI detection module are under development.
              </p>
              <div className="pt-2 border-t border-[#1a2333] text-[11px] font-mono text-slate-400">
                Resolution: 1280×720 · Front Classroom Orientation
              </div>
            </div>

            {/* Bottom Bar Overlay */}
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] font-mono text-slate-400 pointer-events-none">
              <div className="bg-black/70 px-2 py-0.5 rounded border border-slate-800">
                MODEL: PROTOTYPE-HEURISTIC
              </div>
              <div className="bg-black/70 px-2 py-0.5 rounded border border-slate-800">
                CLASSROOM: CSE-A
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Detection Information Panel */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Detection Information</h2>
            <Activity className="w-4 h-4 text-teal-400" />
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-[10px] text-slate-400 uppercase font-mono">Current Student</span>
              <div className="mt-1 text-sm font-medium text-slate-400">Not detected</div>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-[10px] text-slate-400 uppercase font-mono">Seat</span>
              <div className="mt-1 text-sm font-mono text-slate-400">--</div>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-[10px] text-slate-400 uppercase font-mono">Detection</span>
              <div className="mt-1 text-sm font-medium text-slate-400">None</div>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-[10px] text-slate-400 uppercase font-mono">Behaviour</span>
              <div className="mt-1 text-sm font-medium text-emerald-400">Normal</div>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-[10px] text-slate-400 uppercase font-mono">Confidence</span>
              <div className="mt-1 text-sm font-mono text-slate-400">--</div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#18202e] text-[11px] text-slate-400">
            Note: Values update when hardware feed and AI classification models are connected.
          </div>
        </div>
      </div>

      {/* Detection History Table Below Main Area */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">Detection History</h2>
            <p className="text-xs text-slate-400">Simulated demonstration log records for classroom CSE-A</p>
          </div>
          <span className="text-[10px] font-mono text-slate-400">DEMO RECORDS ONLY</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] text-slate-400 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Student</th>
                <th className="py-2.5 px-3">Seat</th>
                <th className="py-2.5 px-3">Detection</th>
                <th className="py-2.5 px-3">Behaviour</th>
                <th className="py-2.5 px-3 text-right">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {records.map((rec) => (
                <tr key={rec.id} className="hover:bg-[#131823]">
                  <td className="py-2.5 px-3 font-mono text-slate-400">{rec.time}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-200">{rec.studentName}</td>
                  <td className="py-2.5 px-3 font-mono text-cyan-400">{rec.seat}</td>
                  <td className="py-2.5 px-3">{rec.detectionType}</td>
                  <td className="py-2.5 px-3">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      rec.behaviour === 'Mobile Usage'
                        ? 'bg-amber-950/70 text-amber-300 border border-amber-800/40'
                        : rec.behaviour === 'Focused'
                          ? 'bg-teal-950/70 text-teal-300 border border-teal-800/40'
                          : 'bg-slate-800 text-slate-300'
                    }`}>
                      {rec.behaviour}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-teal-400">{rec.confidence}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
