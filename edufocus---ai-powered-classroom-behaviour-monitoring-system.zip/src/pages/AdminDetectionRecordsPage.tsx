import React, { useState } from 'react';
import { 
  ScanEye, 
  Search, 
  Download, 
  Info,
  Filter
} from 'lucide-react';
import { DetectionRecord } from '../types';

interface AdminDetectionRecordsPageProps {
  records: DetectionRecord[];
}

export const AdminDetectionRecordsPage: React.FC<AdminDetectionRecordsPageProps> = ({
  records
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [studentFilter, setStudentFilter] = useState('all');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [behaviourFilter, setBehaviourFilter] = useState('all');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const filteredRecords = records.filter(rec => {
    const matchesSearch = 
      rec.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.seat.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDate = dateFilter === 'all' || rec.date === dateFilter;
    const matchesStudent = studentFilter === 'all' || rec.studentId === studentFilter;
    const matchesClassroom = classroomFilter === 'all' || rec.classroom === classroomFilter;
    const matchesType = typeFilter === 'all' || rec.detectionType === typeFilter;
    const matchesBehaviour = behaviourFilter === 'all' || rec.behaviour === behaviourFilter;

    return matchesSearch && matchesDate && matchesStudent && matchesClassroom && matchesType && matchesBehaviour;
  });

  const handleExport = () => {
    setExportNotice('Exported all master records to edufocus_master_detection_records.csv');
    setTimeout(() => setExportNotice(null), 3000);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Detection Records</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Admin Central Log · Historical Behavioural Telemetry Events across Classrooms & Sessions
          </p>
        </div>
        <button
          onClick={handleExport}
          className="px-3.5 py-2 bg-[#141a24] hover:bg-[#1a2333] border border-[#212b3e] text-slate-200 rounded text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-teal-400" />
          <span>Export Master CSV</span>
        </button>
      </div>

      {exportNotice && (
        <div className="p-3 bg-[#112420] border border-teal-500/50 rounded text-xs text-teal-200">
          {exportNotice}
        </div>
      )}

      {/* Prototype Notice */}
      <div className="p-3 bg-[#111822] border border-[#1e2a3c] rounded text-xs text-slate-400 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200">System Record Log:</strong> Demonstration records for prototype evaluation. AI computer vision models are in development.
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-between bg-[#10141d] p-3 border border-[#1b2332] rounded">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search records by Detection ID, Student, ID, or Seat..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#141a24] border border-[#212b3e] rounded pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>
        <span className="text-xs text-slate-400 font-mono">
          {filteredRecords.length} Records Found
        </span>
      </div>

      {/* 5 Filters: Date, Student, Classroom, Detection Type, Behaviour */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs bg-[#131822] p-3 rounded border border-[#1d2638]">
        <div>
          <label className="block text-slate-400 mb-1">Date</label>
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2 py-1.5 rounded outline-none"
          >
            <option value="all">All Dates</option>
            <option value="2026-10-07">2026-10-07</option>
            <option value="2026-10-06">2026-10-06</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Student</label>
          <select
            value={studentFilter}
            onChange={(e) => setStudentFilter(e.target.value)}
            className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2 py-1.5 rounded outline-none"
          >
            <option value="all">All Students</option>
            <option value="STU009">Ishaan Verma (STU009)</option>
            <option value="STU003">Callum Wright (STU003)</option>
            <option value="STU014">Noah Becker (STU014)</option>
            <option value="STU012">Lucas Rossi (STU012)</option>
            <option value="STU017">Quinn Gallagher (STU017)</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Classroom</label>
          <select
            value={classroomFilter}
            onChange={(e) => setClassroomFilter(e.target.value)}
            className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2 py-1.5 rounded outline-none"
          >
            <option value="all">All Classrooms</option>
            <option value="CSE-A">CSE-A</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Detection Type</label>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2 py-1.5 rounded outline-none"
          >
            <option value="all">All Types</option>
            <option value="Mobile Phone">Mobile Phone</option>
            <option value="Drowsiness">Drowsiness</option>
            <option value="Posture Alert">Posture Alert</option>
            <option value="Gaze Deviation">Gaze Deviation</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Behaviour</label>
          <select
            value={behaviourFilter}
            onChange={(e) => setBehaviourFilter(e.target.value)}
            className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2 py-1.5 rounded outline-none"
          >
            <option value="all">All Behaviours</option>
            <option value="Mobile Usage">Mobile Usage</option>
            <option value="Normal">Normal</option>
            <option value="Focused">Focused</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Table: Detection ID, Date, Time, Student, Student ID, Classroom, Seat, Detection Type, Behaviour, Confidence, Source */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] border-b border-[#1b2332] text-slate-400 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-3">Detection ID</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Time</th>
                <th className="py-3 px-3">Student</th>
                <th className="py-3 px-3">Student ID</th>
                <th className="py-3 px-3">Classroom</th>
                <th className="py-3 px-3">Seat</th>
                <th className="py-3 px-3">Detection Type</th>
                <th className="py-3 px-3">Behaviour</th>
                <th className="py-3 px-3">Confidence</th>
                <th className="py-3 px-3">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-400">
                    No detection records match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-[#131823] transition-colors">
                    <td className="py-3 px-3 font-mono text-cyan-400 font-medium">
                      {rec.id}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {rec.date}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {rec.time}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-200">
                      {rec.studentName}
                    </td>
                    <td className="py-3 px-3 font-mono text-cyan-300">
                      {rec.studentId}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {rec.classroom}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {rec.seat}
                    </td>
                    <td className="py-3 px-3 font-medium">
                      {rec.detectionType}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        rec.behaviour === 'Mobile Usage'
                          ? 'bg-amber-950/70 text-amber-300 border border-amber-800/40'
                          : rec.behaviour === 'Focused'
                            ? 'bg-teal-950/70 text-teal-300 border border-teal-800/40'
                            : 'bg-slate-800 text-slate-300'
                      }`}>
                        {rec.behaviour}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-teal-400">
                      {rec.confidence}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {rec.source}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
