import React from 'react';
import { 
  BarChart3, 
  Building2, 
  Users, 
  Activity, 
  Download, 
  TrendingUp, 
  Calendar,
  FileSpreadsheet
} from 'lucide-react';
import { DetectionRecord } from '../types';

interface AdminReportsPageProps {
  records: DetectionRecord[];
}

export const AdminReportsPage: React.FC<AdminReportsPageProps> = ({
  records
}) => {
  const totalEvents = records.length + 20;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Institutional Reports & Telemetry</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Admin System-Wide Analytics · Behaviour Trends, Classroom Aggregates & Longitudinal Metrics
          </p>
        </div>
        <button
          onClick={() => {}}
          className="px-3.5 py-1.5 bg-[#141a24] hover:bg-[#1a2333] border border-[#212b3e] text-slate-200 rounded text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-teal-400" />
          <span>Export Institution Summary</span>
        </button>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="text-xs text-slate-400">Total Detection Events</div>
          <div className="mt-2 text-2xl font-bold font-mono text-slate-100">{totalEvents}</div>
          <p className="mt-1 text-[11px] text-slate-400">Recorded across 4 classrooms</p>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="text-xs text-slate-400">Active Facilities Monitored</div>
          <div className="mt-2 text-2xl font-bold font-mono text-cyan-400">4 Classrooms</div>
          <p className="mt-1 text-[11px] text-slate-400">CSE-A, ECE-B, MECH-C, AUD-1</p>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="text-xs text-slate-400">Average Attention Benchmark</div>
          <div className="mt-2 text-2xl font-bold font-mono text-teal-400">83.5%</div>
          <p className="mt-1 text-[11px] text-slate-400">Cohort engagement index</p>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="text-xs text-slate-400">Mobile Device Gaze Rate</div>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-400">4.8%</div>
          <p className="mt-1 text-[11px] text-slate-400">Down 1.2% from prior term</p>
        </div>
      </div>

      {/* Charts Grid: Classroom-wise Events, Behaviour Distribution, Daily Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Classroom-wise Events */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Classroom-wise Events</h2>
            <Building2 className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-3.5 text-xs pt-1">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>CSE-A (Dr. Aris Vance)</span>
                <span className="font-mono text-cyan-300 font-semibold">14 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-cyan-500 h-full rounded-full" style={{ width: '70%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>ECE-B (Prof. Elena Rostova)</span>
                <span className="font-mono text-teal-300 font-semibold">8 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-teal-500 h-full rounded-full" style={{ width: '40%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>MECH-C (Dr. Marcus Thorne)</span>
                <span className="font-mono text-slate-300 font-semibold">4 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-slate-500 h-full rounded-full" style={{ width: '20%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>AUD-1 (Central Hall)</span>
                <span className="font-mono text-slate-400 font-semibold">2 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-slate-600 h-full rounded-full" style={{ width: '10%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Behaviour Distribution */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Behaviour Distribution</h2>
            <Activity className="w-4 h-4 text-teal-400" />
          </div>

          <div className="space-y-3.5 text-xs pt-1">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Mobile Phone Usage</span>
                <span className="font-mono text-amber-400 font-semibold">46%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '46%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Lateral Head Deviations</span>
                <span className="font-mono text-teal-400 font-semibold">32%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-teal-500 h-full rounded-full" style={{ width: '32%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Drowsiness & Head Slump</span>
                <span className="font-mono text-rose-400 font-semibold">22%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '22%' }} />
              </div>
            </div>
          </div>
          <div className="text-[11px] text-slate-400">Classified across 28 simulated events.</div>
        </div>

        {/* Daily Detection Trends */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Daily Detection Trends</h2>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>

          <div className="h-44 flex items-end justify-between gap-2 pt-6 px-2">
            {[
              { day: 'Mon', count: 4 },
              { day: 'Tue', count: 7 },
              { day: 'Wed', count: 9 },
              { day: 'Thu', count: 5 },
              { day: 'Fri', count: 3 },
            ].map((col, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                <span className="text-[10px] font-mono text-slate-400">{col.count}</span>
                <div 
                  className="w-full bg-cyan-500/80 hover:bg-cyan-400 rounded-t transition-all"
                  style={{ height: `${(col.count / 10) * 100}%` }}
                />
                <span className="text-[10px] font-mono text-slate-400">{col.day}</span>
              </div>
            ))}
          </div>
          <div className="text-[11px] text-slate-400 text-center">Peak volume observed on Wednesday mid-terms.</div>
        </div>
      </div>
    </div>
  );
};
