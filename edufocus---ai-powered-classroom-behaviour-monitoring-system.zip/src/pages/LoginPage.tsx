import React, { useState } from 'react';
import { 
  GraduationCap, 
  ShieldCheck, 
  ArrowRight, 
  Lock, 
  User, 
  Building, 
  Eye, 
  EyeOff, 
  AlertCircle,
  KeyRound
} from 'lucide-react';
import { UserRole } from '../types';

interface LoginPageProps {
  onLogin: (role: UserRole) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>('teacher');
  const [identifier, setIdentifier] = useState('teacher@edufocus.local');
  const [password, setPassword] = useState('teacher123');
  const [showPassword, setShowPassword] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleRoleChange = (role: UserRole) => {
    setSelectedRole(role);
    setValidationError(null);
    if (role === 'teacher') {
      setIdentifier('teacher@edufocus.local');
      setPassword('teacher123');
    } else {
      setIdentifier('admin@edufocus.local');
      setPassword('admin123');
    }
  };

  const handleQuickFill = (role: UserRole) => {
    setSelectedRole(role);
    setValidationError(null);
    if (role === 'teacher') {
      setIdentifier('teacher@edufocus.local');
      setPassword('teacher123');
    } else {
      setIdentifier('admin@edufocus.local');
      setPassword('admin123');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const cleanId = identifier.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanId || !cleanPass) {
      setValidationError('Please enter both Email / User ID and Password.');
      return;
    }

    if (selectedRole === 'teacher') {
      const isTeacherId = cleanId === 'teacher@edufocus.local' || cleanId === 'teacher';
      const isTeacherPass = cleanPass === 'teacher123';
      if (!isTeacherId || !isTeacherPass) {
        setValidationError('Invalid Teacher credentials. Use teacher@edufocus.local / teacher123');
        return;
      }
      onLogin('teacher');
    } else if (selectedRole === 'admin') {
      const isAdminId = cleanId === 'admin@edufocus.local' || cleanId === 'admin';
      const isAdminPass = cleanPass === 'admin123';
      if (!isAdminId || !isAdminPass) {
        setValidationError('Invalid Admin credentials. Use admin@edufocus.local / admin123');
        return;
      }
      onLogin('admin');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0d13] flex flex-col justify-between text-slate-200">
      {/* Top Academic Bar */}
      <header className="px-6 sm:px-8 py-4 border-b border-[#161c28] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#102227] border border-teal-500/40 flex items-center justify-center text-teal-400">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <span className="text-sm font-semibold tracking-wider text-slate-100">EDUFOCUS</span>
            <span className="text-xs text-slate-400 ml-2 hidden sm:inline">AI-Powered Classroom Behaviour Monitoring System</span>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-teal-400" />
          <span className="hidden sm:inline">Academic Prototype Client</span>
        </div>
      </header>

      {/* Main Login Card */}
      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md bg-[#0f141d] border border-[#1b2332] rounded-lg p-6 sm:p-7 shadow-2xl">
          <div className="mb-6">
            <div className="flex items-center gap-2 text-teal-400 text-xs font-mono mb-1">
              <span className="w-2 h-2 rounded-full bg-teal-400"></span>
              <span>SECURE ACCESS PORTAL</span>
            </div>
            <h1 className="text-xl font-bold text-slate-100">Portal Authentication</h1>
            <p className="text-xs text-slate-400 mt-1">
              AI-Powered Classroom Behaviour Monitoring System
            </p>
          </div>

          {/* Validation Alert Box */}
          {validationError && (
            <div className="mb-4 p-3 bg-rose-950/60 border border-rose-700/60 rounded text-xs text-rose-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{validationError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Role Selection */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Select User Role
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-[#151a24] rounded border border-[#212b3e]">
                <button
                  type="button"
                  onClick={() => handleRoleChange('teacher')}
                  className={`py-2 text-xs rounded transition-colors cursor-pointer font-medium ${
                    selectedRole === 'teacher'
                      ? 'bg-[#1a2930] text-teal-300 border border-teal-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Teacher
                </button>
                <button
                  type="button"
                  onClick={() => handleRoleChange('admin')}
                  className={`py-2 text-xs rounded transition-colors cursor-pointer font-medium ${
                    selectedRole === 'admin'
                      ? 'bg-[#1a2930] text-teal-300 border border-teal-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Admin
                </button>
              </div>
            </div>

            {/* Email / User ID Field */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Email / User ID
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    setValidationError(null);
                  }}
                  required
                  className="w-full bg-[#131822] border border-[#222c3d] rounded pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  placeholder={selectedRole === 'teacher' ? 'teacher@edufocus.local' : 'admin@edufocus.local'}
                />
              </div>
            </div>

            {/* Password Field with Show/Hide toggle */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setValidationError(null);
                  }}
                  required
                  className="w-full bg-[#131822] border border-[#222c3d] rounded pl-9 pr-10 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 font-mono"
                  placeholder="••••••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2 text-slate-400 hover:text-slate-200 p-0.5 cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-teal-400" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Host node tag */}
            <div className="flex items-center gap-2 p-2 bg-[#121620] border border-[#1b2230] rounded text-[11px] text-slate-400">
              <Building className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span>Node: EDUFOCUS-CORE-01 (Prototype Environment)</span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
            >
              <span>Login as {selectedRole === 'teacher' ? 'Teacher' : 'Admin'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Demo Credentials Box */}
          <div className="mt-5 pt-4 border-t border-[#1b2332] space-y-2">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-400">
              <KeyRound className="w-3.5 h-3.5" />
              <span>DEMO PROTOTYPE CREDENTIALS</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => handleQuickFill('teacher')}
                className="p-2 bg-[#131b24] hover:bg-[#182330] border border-[#1f2d3d] rounded text-left transition-colors cursor-pointer"
              >
                <div className="font-semibold text-teal-300">Teacher Demo</div>
                <div className="text-slate-400 truncate">teacher@edufocus.local</div>
                <div className="text-slate-400 font-mono">Pass: teacher123</div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('admin')}
                className="p-2 bg-[#131b24] hover:bg-[#182330] border border-[#1f2d3d] rounded text-left transition-colors cursor-pointer"
              >
                <div className="font-semibold text-teal-300">Admin Demo</div>
                <div className="text-slate-400 truncate">admin@edufocus.local</div>
                <div className="text-slate-400 font-mono">Pass: admin123</div>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Academic Disclaimer Footer */}
      <footer className="px-6 sm:px-8 py-3.5 border-t border-[#161c28] text-center text-[11px] text-slate-400">
        College Engineering Prototype · EDUFOCUS Behaviour Telemetry · Strictly for Academic Evaluation
      </footer>
    </div>
  );
};
