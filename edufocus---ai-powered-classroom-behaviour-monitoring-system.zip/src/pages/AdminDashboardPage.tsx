import React from 'react';
import { 
  GraduationCap, 
  Users, 
  Building2, 
  ScanEye, 
  Activity, 
  Clock, 
  ArrowRight, 
  ShieldCheck, 
  AlertTriangle,
  Info,
  Sliders,
  VideoOff
} from 'lucide-react';
import { PageType, TeacherMember, ClassroomRoom, SystemActivity, DetectionRecord } from '../types';

interface AdminDashboardPageProps {
  onNavigate: (page: PageType) => void;
  teachers: TeacherMember[];
  classrooms: ClassroomRoom[];
  studentsCount: number;
  records: DetectionRecord[];
  systemActivities: SystemActivity[];
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({
  onNavigate,
  teachers,
  classrooms,
  studentsCount,
  records,
  systemActivities
}) => {
  const activeClassrooms = classrooms.filter(c => c.cameraStatus === 'Connected' || c.classroomName === 'CSE-A').length;
  const totalDetectionEvents = records.length + 10; // cumulative mock

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Admin Dashboard Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Admin Dashboard</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional Administration · System-Wide Analytics & Infrastructure Topology
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('teachers')}
            className="px-3.5 py-1.5 bg-[#14262c] text-teal-300 border border-teal-500/50 hover:bg-[#183139] rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Manage Teachers</span>
          </button>
          <button
            onClick={() => onNavigate('classrooms')}
            className="px-3.5 py-1.5 bg-[#141a24] text-slate-200 border border-[#212b3e] hover:bg-[#1a2333] rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Classroom Topology</span>
          </button>
        </div>
      </div>

      {/* Prototype Notice */}
      <div className="p-3 bg-[#111822] border border-[#1e2a3c] rounded text-xs text-slate-400 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200">System Admin Control Center:</strong> Displaying mock institutional records. Hardware camera feeds and AI recognition services are marked as under development.
        </div>
      </div>

      {/* Required KPI Cards: Total Teachers, Total Students, Total Classrooms, Detection Events, Active Classrooms */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Card 1: Total Teachers */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Teachers</span>
            <GraduationCap className="w-4 h-4 text-teal-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{teachers.length}</span>
            <span className="text-[11px] text-teal-400 font-medium">Faculty</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Registered Teaching Staff
          </p>
        </div>

        {/* Card 2: Total Students */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Students</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{studentsCount}</span>
            <span className="text-[11px] text-cyan-400 font-medium">Enrolled</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Across active sections
          </p>
        </div>

        {/* Card 3: Total Classrooms */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Classrooms</span>
            <Building2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{classrooms.length}</span>
            <span className="text-[11px] text-slate-400 font-medium">Facilities</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Labs & Lecture Halls
          </p>
        </div>

        {/* Card 4: Detection Events */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Detection Events</span>
            <ScanEye className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{totalDetectionEvents}</span>
            <span className="text-[11px] text-amber-400 font-medium">Logged</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Simulated Events in Term
          </p>
        </div>

        {/* Card 5: Active Classrooms */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Classrooms</span>
            <Activity className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{activeClassrooms}</span>
            <span className="text-[11px] text-emerald-400 font-medium">Monitored</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            CSE-A in session
          </p>
        </div>
      </div>

      {/* Main Grid: Classroom Overview + Recent System Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Classroom Overview Table */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
              <div>
                <h2 className="text-sm font-semibold text-slate-200">Classroom Overview</h2>
                <p className="text-xs text-slate-400">Institutional facility and optical sensor status</p>
              </div>
              <button
                onClick={() => onNavigate('classrooms')}
                className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Manage Classrooms</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Table: Classroom, Teacher, Students, Camera Status, Detection Events */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#131822] text-slate-400 uppercase text-[10px] font-mono">
                  <tr>
                    <th className="py-2.5 px-3">Classroom</th>
                    <th className="py-2.5 px-3">Teacher</th>
                    <th className="py-2.5 px-3">Students</th>
                    <th className="py-2.5 px-3">Camera Status</th>
                    <th className="py-2.5 px-3 text-right">Detection Events</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#18202e] text-slate-300">
                  {classrooms.map((room) => {
                    const roomEventsCount = room.classroomName === 'CSE-A' ? 8 : room.classroomName === 'ECE-B' ? 4 : 2;
                    return (
                      <tr key={room.id} className="hover:bg-[#131823] transition-colors">
                        <td className="py-3 px-3 font-mono text-cyan-400 font-bold">
                          {room.classroomName}
                        </td>
                        <td className="py-3 px-3 font-medium text-slate-200">
                          {room.assignedTeacher}
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-300">
                          {room.studentsCount} / {room.capacity}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1 w-max ${
                            room.cameraStatus === 'Connected'
                              ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/50'
                              : room.cameraStatus === 'Standby'
                                ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                                : 'bg-slate-800 text-rose-400'
                          }`}>
                            <VideoOff className="w-3 h-3" />
                            <span>{room.cameraStatus}</span>
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-amber-400 font-semibold">
                          {roomEventsCount} Events
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detection Summary Panel */}
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-3">
            <h2 className="text-sm font-semibold text-slate-200">Detection Summary</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-[#131822] border border-[#1c2434] rounded space-y-1">
                <span className="text-slate-400">Mobile Phone Events</span>
                <div className="text-lg font-bold font-mono text-amber-400">8 Logged</div>
                <p className="text-[10px] text-slate-400">Simulated downward device gaze</p>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1c2434] rounded space-y-1">
                <span className="text-slate-400">Drowsiness & Slump</span>
                <div className="text-lg font-bold font-mono text-rose-400">5 Logged</div>
                <p className="text-[10px] text-slate-400">Head slump duration &gt; 2.5s</p>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1c2434] rounded space-y-1">
                <span className="text-slate-400">Gaze Deviation Alerts</span>
                <div className="text-lg font-bold font-mono text-teal-400">5 Logged</div>
                <p className="text-[10px] text-slate-400">Lateral peer conversation</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Recent System Activity Stream */}
        <div className="space-y-6">
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
              <h2 className="text-sm font-semibold text-slate-200">Recent System Activity</h2>
              <Clock className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="space-y-3">
              {systemActivities.map((act) => (
                <div key={act.id} className="p-2.5 bg-[#131822] border border-[#1c2434] rounded text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-200">{act.actor}</span>
                    <span className="font-mono text-slate-400">{act.timestamp}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    {act.action}
                  </p>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-[#18202e]">
              <button
                onClick={() => onNavigate('system-settings')}
                className="w-full py-2 bg-[#141b25] hover:bg-[#1a2333] text-slate-300 text-xs rounded border border-[#212c3f] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Sliders className="w-3.5 h-3.5 text-teal-400" />
                <span>System Configuration</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
