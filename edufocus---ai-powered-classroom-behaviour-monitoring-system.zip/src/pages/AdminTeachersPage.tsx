import React, { useState } from 'react';
import { 
  GraduationCap, 
  Search, 
  UserPlus, 
  Edit2, 
  Trash2, 
  Eye, 
  X, 
  Check, 
  Building2,
  Mail
} from 'lucide-react';
import { TeacherMember } from '../types';

interface AdminTeachersPageProps {
  teachers: TeacherMember[];
  onAddTeacher: (teacher: TeacherMember) => void;
  onUpdateTeacher: (teacher: TeacherMember) => void;
  onDeleteTeacher: (teacherId: string) => void;
}

export const AdminTeachersPage: React.FC<AdminTeachersPageProps> = ({
  teachers,
  onAddTeacher,
  onUpdateTeacher,
  onDeleteTeacher
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<TeacherMember | null>(null);
  const [viewingTeacher, setViewingTeacher] = useState<TeacherMember | null>(null);

  // Form State
  const [empId, setEmpId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('Computer Science & Engineering');
  const [assignedClassroom, setAssignedClassroom] = useState('CSE-A');
  const [status, setStatus] = useState<'Active' | 'In Session' | 'On Leave'>('Active');

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.empId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empId || !name || !email) return;

    const newTeacher: TeacherMember = {
      id: `tch-${Date.now()}`,
      empId: empId.trim().toUpperCase(),
      name: name.trim(),
      email: email.trim(),
      department: department.trim(),
      assignedClassroom: assignedClassroom.trim(),
      status,
    };

    onAddTeacher(newTeacher);
    setIsAddModalOpen(false);
    resetForm();
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeacher) return;
    onUpdateTeacher(editingTeacher);
    setEditingTeacher(null);
  };

  const resetForm = () => {
    setEmpId('');
    setName('');
    setEmail('');
    setDepartment('Computer Science & Engineering');
    setAssignedClassroom('CSE-A');
    setStatus('Active');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Teacher Management</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Admin Directory · Faculty Registration, Assigned Classrooms & Monitoring Authorizations
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3.5 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Add Teacher</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-between bg-[#10141d] p-3 border border-[#1b2332] rounded">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search teachers by ID, name, email, or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#141a24] border border-[#212b3e] rounded pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>
        <span className="text-xs text-slate-400 font-mono">
          {filteredTeachers.length} Registered Teachers
        </span>
      </div>

      {/* Teachers Table */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] border-b border-[#1b2332] text-slate-400 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-4">Teacher ID</th>
                <th className="py-3 px-4">Name</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Assigned Classroom</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {filteredTeachers.map((teacher) => (
                <tr key={teacher.id} className="hover:bg-[#131823] transition-colors">
                  <td className="py-3 px-4 font-mono text-cyan-400 font-medium">
                    {teacher.empId}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-100 flex items-center gap-2">
                    <div className="w-6 h-6 rounded bg-[#132328] text-teal-300 flex items-center justify-center text-[10px] font-mono border border-teal-600/30">
                      {teacher.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </div>
                    <span>{teacher.name}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono">
                    {teacher.email}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {teacher.department}
                  </td>
                  <td className="py-3 px-4 font-mono text-cyan-300 font-medium">
                    {teacher.assignedClassroom}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      teacher.status === 'In Session'
                        ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/50'
                        : teacher.status === 'Active'
                          ? 'bg-teal-950/60 text-teal-300 border border-teal-800/40'
                          : 'bg-slate-800 text-slate-400'
                    }`}>
                      {teacher.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setViewingTeacher(teacher)}
                        className="p-1 rounded hover:bg-[#1a2332] text-teal-400 hover:text-teal-300 transition-colors cursor-pointer"
                        title="View Teacher"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingTeacher({ ...teacher })}
                        className="p-1 rounded hover:bg-[#1a2332] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                        title="Edit Teacher"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete teacher ${teacher.name} (${teacher.empId})?`)) {
                            onDeleteTeacher(teacher.id);
                          }
                        }}
                        className="p-1 rounded hover:bg-rose-950/30 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                        title="Delete Teacher"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Teacher Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Add Teacher</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTeacher} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Teacher ID</label>
                <input
                  type="text"
                  required
                  placeholder="TCH005"
                  value={empId}
                  onChange={(e) => setEmpId(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Teacher Name</label>
                <input
                  type="text"
                  required
                  placeholder="Dr. / Prof. Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Institutional Email</label>
                <input
                  type="email"
                  required
                  placeholder="teacher@edufocus.local"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Department</label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                  <option value="Robotics & Automation">Robotics & Automation</option>
                  <option value="Electrical & Electronics">Electrical & Electronics</option>
                  <option value="Artificial Intelligence & Data Science">Artificial Intelligence & Data Science</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Assigned Classroom</label>
                <input
                  type="text"
                  value={assignedClassroom}
                  onChange={(e) => setAssignedClassroom(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as 'Active' | 'In Session' | 'On Leave')}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Active">Active</option>
                  <option value="In Session">In Session</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Save Teacher Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Teacher Modal */}
      {editingTeacher && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Edit Teacher: {editingTeacher.name}</h3>
              <button onClick={() => setEditingTeacher(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Teacher ID</label>
                <input
                  type="text"
                  required
                  value={editingTeacher.empId}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, empId: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Name</label>
                <input
                  type="text"
                  required
                  value={editingTeacher.name}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, name: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={editingTeacher.email}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, email: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Department</label>
                <input
                  type="text"
                  required
                  value={editingTeacher.department}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, department: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Assigned Classroom</label>
                <input
                  type="text"
                  required
                  value={editingTeacher.assignedClassroom}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, assignedClassroom: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Status</label>
                <select
                  value={editingTeacher.status}
                  onChange={(e) => setEditingTeacher({ ...editingTeacher, status: e.target.value as 'Active' | 'In Session' | 'On Leave' })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Active">Active</option>
                  <option value="In Session">In Session</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setEditingTeacher(null)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Update Teacher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Teacher Modal */}
      {viewingTeacher && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <div>
                <h3 className="text-base font-bold text-slate-100">{viewingTeacher.name}</h3>
                <span className="text-xs font-mono text-cyan-400">{viewingTeacher.empId}</span>
              </div>
              <button onClick={() => setViewingTeacher(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                <span className="text-slate-400 text-[10px]">EMAIL</span>
                <div className="text-slate-200 font-mono mt-0.5">{viewingTeacher.email}</div>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                <span className="text-slate-400 text-[10px]">DEPARTMENT</span>
                <div className="text-slate-200 mt-0.5">{viewingTeacher.department}</div>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-[10px]">ASSIGNED CLASSROOM</span>
                  <div className="text-cyan-300 font-mono font-bold mt-0.5">{viewingTeacher.assignedClassroom}</div>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px]">SESSION STATUS</span>
                  <div className="text-teal-400 font-mono mt-0.5">{viewingTeacher.status}</div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#1c2434]">
              <button
                onClick={() => setViewingTeacher(null)}
                className="px-4 py-1.5 bg-[#1a2332] hover:bg-[#202b3d] text-slate-200 text-xs rounded cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
