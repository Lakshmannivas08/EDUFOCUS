import React, { useState } from 'react';
import { 
  Search, 
  UserPlus, 
  Edit2, 
  Trash2, 
  Eye, 
  X, 
  Check, 
  AlertCircle,
  Database,
  Filter
} from 'lucide-react';
import { Student, StudentStatus } from '../types';

interface StudentManagementPageProps {
  students: Student[];
  onUpdateStudent: (student: Student) => void;
  onAddStudent: (student: Student) => void;
  onDeleteStudent: (studentId: string) => void;
}

export const StudentManagementPage: React.FC<StudentManagementPageProps> = ({
  students,
  onUpdateStudent,
  onAddStudent,
  onDeleteStudent,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Add Student Form State
  const [studentId, setStudentId] = useState('');
  const [registerNumber, setRegisterNumber] = useState('');
  const [studentName, setStudentName] = useState('');
  const [email, setEmail] = useState('');
  const [assignedSeat, setAssignedSeat] = useState('S21');
  const [classroom, setClassroom] = useState('CSE-A');
  const [status, setStatus] = useState<StudentStatus>('Normal');

  const filteredStudents = students.filter(student => {
    const matchesSearch = 
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.registerNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.assignedSeat.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = statusFilter === 'all' || student.status === statusFilter;
    return matchesSearch && matchesFilter;
  });

  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !studentName || !registerNumber) return;

    const newStudent: Student = {
      id: `stu-${Date.now()}`,
      studentId: studentId.trim().toUpperCase(),
      registerNumber: registerNumber.trim(),
      name: studentName.trim(),
      email: email.trim() || `${studentId.toLowerCase()}@edufocus.local`,
      assignedSeat: assignedSeat.trim().toUpperCase(),
      classroom: classroom.trim(),
      status,
      detectionCount: 0,
    };

    onAddStudent(newStudent);
    setIsAddModalOpen(false);
    resetForm();
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    onUpdateStudent(editingStudent);
    setEditingStudent(null);
  };

  const resetForm = () => {
    setStudentId('');
    setRegisterNumber('');
    setStudentName('');
    setEmail('');
    setAssignedSeat('S21');
    setClassroom('CSE-A');
    setStatus('Normal');
  };

  const openEditModal = (st: Student) => {
    setEditingStudent({ ...st });
  };

  const getStatusBadge = (stStatus: StudentStatus) => {
    switch (stStatus) {
      case 'Normal':
        return <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-800/40">Normal</span>;
      case 'Focused':
        return <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-950/70 text-teal-300 border border-teal-800/40">Focused</span>;
      case 'Mobile Usage':
        return <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/70 text-amber-300 border border-amber-800/50">Mobile Usage</span>;
      case 'Other':
        return <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950/70 text-rose-300 border border-rose-800/50">Other</span>;
      case 'Absent':
        return <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">Absent</span>;
      default:
        return <span className="text-slate-400">{stStatus}</span>;
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Student Management</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Cohort Records · Class: <span className="text-teal-400 font-medium">CSE-A</span> · {students.length} Enrolled Students
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* MongoDB Ready Architecture Tag */}
      <div className="p-2.5 bg-[#121822] border border-[#1b2536] rounded text-xs text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-cyan-400" />
          <span>Storage Adapter: Local Mock State · Schema optimized for MongoDB `students` collection</span>
        </div>
        <span className="text-[11px] font-mono text-slate-400">Database: Standby / Ready</span>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-[#10141d] p-3 border border-[#1b2332] rounded">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by student ID, register no, name, or seat (e.g. STU005, S05)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#141a24] border border-[#212b3e] rounded pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#141a24] border border-[#212b3e] text-slate-200 px-2.5 py-1.5 rounded outline-none cursor-pointer"
          >
            <option value="all">All Behaviour States</option>
            <option value="Normal">Normal</option>
            <option value="Focused">Focused</option>
            <option value="Mobile Usage">Mobile Usage</option>
            <option value="Other">Other</option>
            <option value="Absent">Absent</option>
          </select>
        </div>
      </div>

      {/* Student Table */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] border-b border-[#1b2332] text-slate-400 uppercase text-[10px] tracking-wider font-mono">
              <tr>
                <th className="py-3 px-3">Student ID</th>
                <th className="py-3 px-3">Register Number</th>
                <th className="py-3 px-3">Name</th>
                <th className="py-3 px-3">Assigned Seat</th>
                <th className="py-3 px-3">Classroom</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-center">Detection Count</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No students match the criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-[#131823] transition-colors">
                    <td className="py-3 px-3 font-mono text-cyan-400 font-medium">
                      {student.studentId}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {student.registerNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-100">
                      {student.name}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {student.assignedSeat}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {student.classroom}
                    </td>
                    <td className="py-3 px-3">
                      {getStatusBadge(student.status)}
                    </td>
                    <td className="py-3 px-3 text-center font-mono tabular-nums text-slate-300">
                      {student.detectionCount}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setViewingStudent(student)}
                          className="p-1 rounded hover:bg-[#1a2332] text-teal-400 hover:text-teal-300 transition-colors cursor-pointer"
                          title="View Student"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEditModal(student)}
                          className="p-1 rounded hover:bg-[#1a2332] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                          title="Edit Student"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to delete student ${student.name} (${student.studentId})?`)) {
                              onDeleteStudent(student.id);
                            }
                          }}
                          className="p-1 rounded hover:bg-rose-950/30 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                          title="Delete Student"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Add Student Record</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateStudent} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Student ID</label>
                  <input
                    type="text"
                    required
                    placeholder="STU021"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Register Number</label>
                  <input
                    type="text"
                    required
                    placeholder="717822P121"
                    value={registerNumber}
                    onChange={(e) => setRegisterNumber(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Student Name</label>
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Institutional Email</label>
                <input
                  type="email"
                  placeholder="student@edufocus.local"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Assigned Seat</label>
                  <input
                    type="text"
                    placeholder="S21"
                    value={assignedSeat}
                    onChange={(e) => setAssignedSeat(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Classroom</label>
                  <input
                    type="text"
                    value={classroom}
                    onChange={(e) => setClassroom(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Initial Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as StudentStatus)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Normal">Normal</option>
                  <option value="Focused">Focused</option>
                  <option value="Mobile Usage">Mobile Usage</option>
                  <option value="Other">Other</option>
                  <option value="Absent">Absent</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Save Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Student Modal */}
      {editingStudent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Edit Student: {editingStudent.name}</h3>
              <button onClick={() => setEditingStudent(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Student ID</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.studentId}
                    onChange={(e) => setEditingStudent({ ...editingStudent, studentId: e.target.value })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Register Number</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.registerNumber}
                    onChange={(e) => setEditingStudent({ ...editingStudent, registerNumber: e.target.value })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Student Name</label>
                <input
                  type="text"
                  required
                  value={editingStudent.name}
                  onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Assigned Seat</label>
                <input
                  type="text"
                  value={editingStudent.assignedSeat}
                  onChange={(e) => setEditingStudent({ ...editingStudent, assignedSeat: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Status</label>
                <select
                  value={editingStudent.status}
                  onChange={(e) => setEditingStudent({ ...editingStudent, status: e.target.value as StudentStatus })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Normal">Normal</option>
                  <option value="Focused">Focused</option>
                  <option value="Mobile Usage">Mobile Usage</option>
                  <option value="Other">Other</option>
                  <option value="Absent">Absent</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Update Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Student Modal */}
      {viewingStudent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <div>
                <h3 className="text-base font-bold text-slate-100">{viewingStudent.name}</h3>
                <span className="text-xs font-mono text-cyan-400">{viewingStudent.studentId} · {viewingStudent.registerNumber}</span>
              </div>
              <button onClick={() => setViewingStudent(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#151c27] rounded border border-[#1e2738]">
                <div className="text-slate-400">Assigned Seat</div>
                <div className="mt-1 text-sm font-mono font-bold text-slate-100">{viewingStudent.assignedSeat}</div>
              </div>
              <div className="p-3 bg-[#151c27] rounded border border-[#1e2738]">
                <div className="text-slate-400">Classroom</div>
                <div className="mt-1 text-sm font-mono font-bold text-slate-100">{viewingStudent.classroom}</div>
              </div>
              <div className="p-3 bg-[#151c27] rounded border border-[#1e2738]">
                <div className="text-slate-400">Behaviour Status</div>
                <div className="mt-1">{getStatusBadge(viewingStudent.status)}</div>
              </div>
              <div className="p-3 bg-[#151c27] rounded border border-[#1e2738]">
                <div className="text-slate-400">Detection Count</div>
                <div className="mt-1 text-sm font-mono font-bold text-amber-400">{viewingStudent.detectionCount} events</div>
              </div>
            </div>

            <div className="p-3 bg-[#141a24] rounded border border-[#1e2738] text-xs">
              <div className="text-slate-400 mb-1">Email</div>
              <div className="text-slate-200 font-mono">{viewingStudent.email}</div>
            </div>

            {viewingStudent.notes && (
              <div className="p-3 bg-[#141a24] rounded border border-[#1e2738] text-xs">
                <div className="text-slate-400 mb-1">Observations / Notes</div>
                <div className="text-slate-300">{viewingStudent.notes}</div>
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-[#1c2434]">
              <button
                onClick={() => setViewingStudent(null)}
                className="px-4 py-1.5 bg-[#1a2332] hover:bg-[#202b3d] text-slate-200 text-xs rounded cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
