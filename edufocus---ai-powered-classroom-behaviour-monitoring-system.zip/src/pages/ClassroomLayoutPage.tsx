import React, { useState } from 'react';
import { 
  Building2, 
  Camera, 
  VideoOff, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  MinusCircle,
  ArrowRight,
  Info,
  UserCheck
} from 'lucide-react';
import { Student, PageType } from '../types';

interface ClassroomLayoutPageProps {
  students: Student[];
  onNavigate: (page: PageType) => void;
}

export const ClassroomLayoutPage: React.FC<ClassroomLayoutPageProps> = ({
  students,
  onNavigate
}) => {
  // 4 rows x 5 columns = S01 to S20
  const rows = [
    { rowNum: 1, seats: ['S01', 'S02', 'S03', 'S04', 'S05'] },
    { rowNum: 2, seats: ['S06', 'S07', 'S08', 'S09', 'S10'] },
    { rowNum: 3, seats: ['S11', 'S12', 'S13', 'S14', 'S15'] },
    { rowNum: 4, seats: ['S16', 'S17', 'S18', 'S19', 'S20'] },
  ];

  const [selectedSeat, setSelectedSeat] = useState<string>('S05');

  // Map students by assignedSeat
  const studentSeatMap: Record<string, Student> = {};
  students.forEach(st => {
    studentSeatMap[st.assignedSeat] = st;
  });

  const activeStudent = studentSeatMap[selectedSeat] || null;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Classroom Seating Layout</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Physical Topology · Interactive Desk Matrix (4 Rows × 5 Columns · 20 Key Monitoring Desks)
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('detection')}
            className="px-3.5 py-1.5 bg-[#142329] border border-teal-500/40 text-teal-300 rounded text-xs font-semibold flex items-center gap-1.5 hover:bg-[#18313a] transition-colors cursor-pointer"
          >
            <span>Detection Feed</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Classroom Specification Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-xs">
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Classroom Name</span>
          <div className="font-bold font-mono text-slate-100 text-sm mt-0.5">CSE-A</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Building</span>
          <div className="font-medium text-slate-200 mt-0.5 truncate">Computing Block</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Floor</span>
          <div className="font-medium text-slate-200 mt-0.5">2nd Floor</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Capacity</span>
          <div className="font-bold font-mono text-cyan-400 mt-0.5">60 Students</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Rows</span>
          <div className="font-mono text-slate-200 mt-0.5">4 Rows</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Columns</span>
          <div className="font-mono text-slate-200 mt-0.5">5 Columns</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Camera Source</span>
          <div className="font-medium text-teal-400 mt-0.5 truncate">Laptop Webcam</div>
        </div>
        <div className="p-2.5 bg-[#10141d] border border-[#1b2332] rounded">
          <span className="text-[10px] text-slate-400">Camera Status</span>
          <div className="font-medium text-rose-400 mt-0.5 flex items-center gap-1">
            <VideoOff className="w-3 h-3" />
            <span>Not Connected</span>
          </div>
        </div>
      </div>

      {/* Main Seating Workspace & Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: 2D Interactive Desk Matrix */}
        <div className="lg:col-span-2 bg-[#10141d] border border-[#1b2332] rounded p-6 space-y-6">
          {/* Front Camera Indicator & Teacher Podium */}
          <div className="space-y-2">
            {/* Visual Camera Indicator */}
            <div className="w-full py-2 bg-[#141d27] border border-cyan-800/40 rounded flex items-center justify-center gap-2 text-xs font-mono text-cyan-300">
              <Camera className="w-4 h-4 text-cyan-400" />
              <span>LAPTOP WEBCAM (Front Sensor Angle · Status: Not Connected)</span>
            </div>

            {/* Teacher Podium */}
            <div className="w-full py-2 bg-[#141a24] border border-[#212a3b] rounded text-center text-xs font-mono text-slate-300 flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-teal-400"></span>
              <span className="font-semibold text-slate-200">TEACHER PODIUM (FRONT OF CLASS)</span>
            </div>
          </div>

          {/* Seat Grid: 4 Rows x 5 Columns (S01 - S20) */}
          <div className="space-y-3 pt-2">
            {rows.map((row) => (
              <div key={row.rowNum} className="space-y-1">
                <div className="text-[10px] font-mono text-slate-400">Row {row.rowNum}</div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {row.seats.map((seatNum) => {
                    const student = studentSeatMap[seatNum];
                    const isSelected = selectedSeat === seatNum;

                    let stateBorder = 'border-[#21293a] bg-[#131822] text-slate-400';
                    let statusLabel = 'Vacant';
                    let statusBadgeClass = 'text-slate-400 bg-slate-800';

                    if (student) {
                      if (student.status === 'Focused') {
                        stateBorder = 'border-teal-500/40 bg-[#102325] text-slate-200 hover:border-teal-400';
                        statusLabel = 'Focused';
                        statusBadgeClass = 'text-teal-300 bg-teal-950/80';
                      } else if (student.status === 'Normal') {
                        stateBorder = 'border-emerald-500/40 bg-[#11241f] text-slate-200 hover:border-emerald-400';
                        statusLabel = 'Normal';
                        statusBadgeClass = 'text-emerald-300 bg-emerald-950/80';
                      } else if (student.status === 'Mobile Usage') {
                        stateBorder = 'border-amber-500/50 bg-[#241d13] text-slate-200 hover:border-amber-400';
                        statusLabel = 'Mobile Usage';
                        statusBadgeClass = 'text-amber-300 bg-amber-950/80';
                      } else {
                        stateBorder = 'border-rose-500/50 bg-[#241418] text-slate-200 hover:border-rose-400';
                        statusLabel = student.status;
                        statusBadgeClass = 'text-rose-300 bg-rose-950/80';
                      }
                    }

                    return (
                      <button
                        key={seatNum}
                        onClick={() => setSelectedSeat(seatNum)}
                        className={`p-3 rounded border text-left transition-all cursor-pointer relative ${stateBorder} ${
                          isSelected ? 'ring-2 ring-teal-400 shadow-xl' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-mono font-bold text-cyan-300">{seatNum}</span>
                          <span className={`text-[9px] font-mono px-1 py-0.2 rounded ${statusBadgeClass}`}>
                            {statusLabel}
                          </span>
                        </div>
                        <div className="mt-1 font-semibold text-xs text-slate-100 truncate">
                          {student ? student.name : 'Unassigned'}
                        </div>
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                          {student ? student.studentId : '---'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="pt-4 border-t border-[#18202e] flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-teal-400"></span>
                <span>Focused</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-emerald-400"></span>
                <span>Normal</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-amber-400"></span>
                <span>Mobile Usage</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-rose-400"></span>
                <span>Other Alert</span>
              </div>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              Click any seat card to inspect student
            </span>
          </div>
        </div>

        {/* Right Col: Seat & Student Inspector */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Seat Inspector</h2>
            <span className="text-xs font-mono text-cyan-400 font-bold px-2 py-0.5 bg-[#141d27] rounded border border-cyan-800/40">
              {selectedSeat}
            </span>
          </div>

          {activeStudent ? (
            <div className="space-y-4 text-xs">
              <div>
                <div className="text-base font-bold text-slate-100">{activeStudent.name}</div>
                <div className="text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                  <span>ID: {activeStudent.studentId}</span>
                  <span aria-hidden="true">·</span>
                  <span>Reg: {activeStudent.registerNumber}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-2.5 bg-[#141a24] rounded border border-[#212b3c]">
                  <span className="text-slate-400 text-[10px]">CURRENT BEHAVIOUR</span>
                  <div className="mt-1 font-semibold text-slate-200">
                    {activeStudent.status}
                  </div>
                </div>

                <div className="p-2.5 bg-[#141a24] rounded border border-[#212b3c]">
                  <span className="text-slate-400 text-[10px]">DETECTION COUNT</span>
                  <div className="mt-1 font-mono text-sm font-bold text-amber-400">
                    {activeStudent.detectionCount} Flagged
                  </div>
                </div>
              </div>

              <div className="p-3 bg-[#131822] rounded border border-[#1d2638] space-y-1.5">
                <div className="text-slate-400 text-[11px]">Seat Allocation Record</div>
                <div className="text-slate-200 font-medium font-mono">
                  Assigned Seat: {activeStudent.assignedSeat} · Class: {activeStudent.classroom}
                </div>
                <p className="text-[11px] text-slate-400">
                  {activeStudent.notes || 'Normal participation observed. Front orientation aligned.'}
                </p>
              </div>

              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Contact Email:</span>
                <span className="font-mono text-slate-300">{activeStudent.email}</span>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <MinusCircle className="w-8 h-8 mx-auto text-slate-600" />
              <p className="text-xs">Seat {selectedSeat} is currently unassigned.</p>
            </div>
          )}

          <div className="pt-3 border-t border-[#18202e]">
            <button
              onClick={() => onNavigate('students')}
              className="w-full py-2 bg-[#141b25] hover:bg-[#1a2332] text-slate-300 text-xs rounded border border-[#212c3f] transition-colors cursor-pointer"
            >
              Open Student Management Roster
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
