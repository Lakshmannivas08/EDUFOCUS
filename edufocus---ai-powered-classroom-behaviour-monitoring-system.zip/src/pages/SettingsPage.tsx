import React, { useState } from 'react';
import { 
  User, 
  Building2, 
  Camera, 
  Cpu, 
  Info, 
  Save, 
  Check, 
  VideoOff, 
  Lock,
  Layers
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  // Teacher Profile state
  const [name, setName] = useState('Dr. Aris Vance');
  const [teacherId, setTeacherId] = useState('TCH001');
  const [email, setEmail] = useState('teacher@edufocus.local');
  const [department, setDepartment] = useState('Dept. of Computer Science & Engineering');

  // Classroom Settings state
  const [classroomName, setClassroomName] = useState('CSE-A');
  const [building, setBuilding] = useState('Computing Sciences Block');
  const [floor, setFloor] = useState('2nd Floor');
  const [capacity, setCapacity] = useState(60);

  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Teacher Settings</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Profile Preferences, Active Classroom Parameters & Optical Sensor Specs
          </p>
        </div>

        {savedNotice && (
          <div className="flex items-center gap-1.5 px-3 py-1 bg-teal-950/80 border border-teal-500/50 rounded text-xs text-teal-300">
            <Check className="w-3.5 h-3.5 text-teal-400" />
            <span>Settings Saved (Prototype Local State)</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Teacher Profile */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#18202e] text-slate-200">
            <User className="w-4 h-4 text-teal-400" />
            <h2 className="text-sm font-semibold">Teacher Profile</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Teacher ID</label>
              <input
                type="text"
                value={teacherId}
                onChange={(e) => setTeacherId(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Institutional Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Academic Department</label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Classroom Settings */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#18202e] text-slate-200">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold">Classroom Settings</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Classroom Name</label>
              <input
                type="text"
                value={classroomName}
                onChange={(e) => setClassroomName(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Building</label>
              <input
                type="text"
                value={building}
                onChange={(e) => setBuilding(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Floor</label>
              <input
                type="text"
                value={floor}
                onChange={(e) => setFloor(e.target.value)}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Seating Capacity</label>
              <input
                type="number"
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full bg-[#141a24] border border-[#20293a] text-slate-200 p-2 rounded focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Camera Configuration */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#18202e] text-slate-200">
            <Camera className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-semibold">Camera Configuration</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">CURRENT CAMERA SOURCE</span>
              <div className="font-semibold text-teal-300 mt-1">Laptop Webcam</div>
              <p className="text-[10px] text-slate-400 mt-0.5">Built-in front laptop sensor</p>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">HARDWARE STATUS</span>
              <div className="font-semibold text-rose-400 mt-1 flex items-center gap-1.5">
                <VideoOff className="w-3.5 h-3.5" />
                <span>Not Connected</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">Stream disconnected in prototype</p>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">FUTURE CAMERA CAPABILITY</span>
              <div className="font-semibold text-cyan-300 mt-1">CCTV / IP Camera</div>
              <p className="text-[10px] text-cyan-400/80 mt-0.5">RTSP / ONVIF ceiling stream</p>
            </div>
          </div>
        </div>

        {/* Section 4: System Information */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#18202e] text-slate-200">
            <Layers className="w-4 h-4 text-teal-400" />
            <h2 className="text-sm font-semibold">System Information</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">APPLICATION</span>
              <div className="font-bold text-slate-100 mt-1">EDUFOCUS</div>
              <p className="text-[10px] text-slate-400 mt-0.5">AI Classroom Behaviour Monitoring</p>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">BACKEND SERVICE</span>
              <div className="font-mono font-bold text-teal-400 mt-1">Node.js / Express</div>
              <p className="text-[10px] text-slate-400 mt-0.5">RESTful APIs on port 5000</p>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">DATABASE ARCHITECTURE</span>
              <div className="font-mono font-bold text-emerald-400 mt-1">MongoDB (eduFocusDB)</div>
              <p className="text-[10px] text-slate-400 mt-0.5">Mongoose ODM + fallback store</p>
            </div>

            <div className="p-3 bg-[#131822] border border-[#1c2434] rounded">
              <span className="text-slate-400 text-[10px]">DEPLOYMENT STAGE</span>
              <div className="font-mono font-bold text-amber-400 mt-1">Prototype Evaluation</div>
              <p className="text-[10px] text-slate-400 mt-0.5">Not production certified</p>
            </div>
          </div>
        </div>

        {/* Save Actions */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Preferences</span>
          </button>
        </div>
      </form>
    </div>
  );
};
