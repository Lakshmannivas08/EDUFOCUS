import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Eye, 
  X, 
  VideoOff, 
  Camera,
  Layers
} from 'lucide-react';
import { ClassroomRoom } from '../types';

interface AdminClassroomsPageProps {
  classrooms: ClassroomRoom[];
  onAddClassroom: (room: ClassroomRoom) => void;
  onUpdateClassroom: (room: ClassroomRoom) => void;
  onDeleteClassroom: (classroomId: string) => void;
}

export const AdminClassroomsPage: React.FC<AdminClassroomsPageProps> = ({
  classrooms,
  onAddClassroom,
  onUpdateClassroom,
  onDeleteClassroom
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<ClassroomRoom | null>(null);
  const [viewingRoom, setViewingRoom] = useState<ClassroomRoom | null>(null);

  // Form State
  const [classroomId, setClassroomId] = useState('');
  const [classroomName, setClassroomName] = useState('');
  const [building, setBuilding] = useState('Computing Sciences Block');
  const [floor, setFloor] = useState('2nd Floor');
  const [capacity, setCapacity] = useState(60);
  const [rows, setRows] = useState(4);
  const [columns, setColumns] = useState(5);
  const [cameraType, setCameraType] = useState<'Laptop Webcam' | 'External Webcam' | 'CCTV / IP Camera'>('Laptop Webcam');
  const [assignedTeacher, setAssignedTeacher] = useState('Dr. Aris Vance');

  const filteredClassrooms = classrooms.filter(c => 
    c.classroomName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.classroomId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.building.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.assignedTeacher.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateClassroom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!classroomId || !classroomName) return;

    const newRoom: ClassroomRoom = {
      id: `cls-${Date.now()}`,
      classroomId: classroomId.trim().toUpperCase(),
      classroomName: classroomName.trim(),
      building: building.trim(),
      floor: floor.trim(),
      capacity: Number(capacity),
      rows: Number(rows),
      columns: Number(columns),
      assignedTeacher: assignedTeacher.trim(),
      studentsCount: Math.min(Number(capacity), 60),
      cameraType,
      cameraStatus: cameraType === 'Laptop Webcam' ? 'Not Connected' : 'Standby',
    };

    onAddClassroom(newRoom);
    setIsAddModalOpen(false);
    resetForm();
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRoom) return;
    onUpdateClassroom(editingRoom);
    setEditingRoom(null);
  };

  const resetForm = () => {
    setClassroomId('');
    setClassroomName('');
    setBuilding('Computing Sciences Block');
    setFloor('2nd Floor');
    setCapacity(60);
    setRows(4);
    setColumns(5);
    setCameraType('Laptop Webcam');
    setAssignedTeacher('Dr. Aris Vance');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Classroom Management</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Admin Facility Directory · Physical Dimensions, Seating Grids & Optical Sensor Allocation
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3.5 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Classroom</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-between bg-[#10141d] p-3 border border-[#1b2332] rounded">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search classrooms by ID, name, building, or teacher..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#141a24] border border-[#212b3e] rounded pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>
        <span className="text-xs text-slate-400 font-mono">
          {filteredClassrooms.length} Classrooms Configured
        </span>
      </div>

      {/* Classrooms Table */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] border-b border-[#1b2332] text-slate-400 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-3">Classroom ID</th>
                <th className="py-3 px-3">Classroom Name</th>
                <th className="py-3 px-3">Building</th>
                <th className="py-3 px-3">Floor</th>
                <th className="py-3 px-3">Capacity</th>
                <th className="py-3 px-3">Assigned Teacher</th>
                <th className="py-3 px-3">Students</th>
                <th className="py-3 px-3">Camera Type</th>
                <th className="py-3 px-3">Camera Status</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {filteredClassrooms.map((room) => (
                <tr key={room.id} className="hover:bg-[#131823] transition-colors">
                  <td className="py-3 px-3 font-mono text-cyan-400 font-medium">
                    {room.classroomId}
                  </td>
                  <td className="py-3 px-3 font-semibold text-slate-100">
                    {room.classroomName}
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    {room.building}
                  </td>
                  <td className="py-3 px-3 text-slate-400 font-mono">
                    {room.floor}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-300">
                    {room.capacity} Desks
                  </td>
                  <td className="py-3 px-3 text-slate-200">
                    {room.assignedTeacher}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-300">
                    {room.studentsCount}
                  </td>
                  <td className="py-3 px-3 text-teal-400 font-mono">
                    {room.cameraType}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1 w-max ${
                      room.cameraStatus === 'Connected'
                        ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/50'
                        : room.cameraStatus === 'Standby'
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                          : 'bg-slate-800 text-rose-400'
                    }`}>
                      <VideoOff className="w-3 h-3" />
                      <span>{room.cameraStatus}</span>
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setViewingRoom(room)}
                        className="p-1 rounded hover:bg-[#1a2332] text-teal-400 hover:text-teal-300 transition-colors cursor-pointer"
                        title="View Classroom"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingRoom({ ...room })}
                        className="p-1 rounded hover:bg-[#1a2332] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                        title="Edit Classroom"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete classroom ${room.classroomName} (${room.classroomId})?`)) {
                            onDeleteClassroom(room.id);
                          }
                        }}
                        className="p-1 rounded hover:bg-rose-950/30 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                        title="Delete Classroom"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Classroom Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Add Classroom</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateClassroom} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Classroom ID</label>
                  <input
                    type="text"
                    required
                    placeholder="CLS005"
                    value={classroomId}
                    onChange={(e) => setClassroomId(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Classroom Name</label>
                  <input
                    type="text"
                    required
                    placeholder="CSE-B"
                    value={classroomName}
                    onChange={(e) => setClassroomName(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Building</label>
                <input
                  type="text"
                  required
                  placeholder="Computing Sciences Block"
                  value={building}
                  onChange={(e) => setBuilding(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Floor</label>
                  <input
                    type="text"
                    placeholder="2nd Floor"
                    value={floor}
                    onChange={(e) => setFloor(e.target.value)}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Capacity (Desks)</label>
                  <input
                    type="number"
                    min={10}
                    max={120}
                    value={capacity}
                    onChange={(e) => setCapacity(Number(e.target.value))}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Rows</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={rows}
                    onChange={(e) => setRows(Number(e.target.value))}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Columns</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={columns}
                    onChange={(e) => setColumns(Number(e.target.value))}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Camera Type</label>
                <select
                  value={cameraType}
                  onChange={(e) => setCameraType(e.target.value as 'Laptop Webcam' | 'External Webcam' | 'CCTV / IP Camera')}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Laptop Webcam">Laptop Webcam (Prototype Standard)</option>
                  <option value="External Webcam">External Webcam</option>
                  <option value="CCTV / IP Camera">CCTV / IP Camera (Future capability)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Assigned Teacher</label>
                <input
                  type="text"
                  value={assignedTeacher}
                  onChange={(e) => setAssignedTeacher(e.target.value)}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Save Classroom
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Classroom Modal */}
      {editingRoom && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <h3 className="text-base font-bold text-slate-100">Edit Classroom: {editingRoom.classroomName}</h3>
              <button onClick={() => setEditingRoom(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Classroom ID</label>
                  <input
                    type="text"
                    required
                    value={editingRoom.classroomId}
                    onChange={(e) => setEditingRoom({ ...editingRoom, classroomId: e.target.value })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Classroom Name</label>
                  <input
                    type="text"
                    required
                    value={editingRoom.classroomName}
                    onChange={(e) => setEditingRoom({ ...editingRoom, classroomName: e.target.value })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Building</label>
                <input
                  type="text"
                  required
                  value={editingRoom.building}
                  onChange={(e) => setEditingRoom({ ...editingRoom, building: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Floor</label>
                  <input
                    type="text"
                    value={editingRoom.floor}
                    onChange={(e) => setEditingRoom({ ...editingRoom, floor: e.target.value })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Capacity</label>
                  <input
                    type="number"
                    value={editingRoom.capacity}
                    onChange={(e) => setEditingRoom({ ...editingRoom, capacity: Number(e.target.value) })}
                    className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Camera Type</label>
                <select
                  value={editingRoom.cameraType}
                  onChange={(e) => setEditingRoom({ ...editingRoom, cameraType: e.target.value as any })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                >
                  <option value="Laptop Webcam">Laptop Webcam</option>
                  <option value="External Webcam">External Webcam</option>
                  <option value="CCTV / IP Camera">CCTV / IP Camera (Future capability)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Assigned Teacher</label>
                <input
                  type="text"
                  value={editingRoom.assignedTeacher}
                  onChange={(e) => setEditingRoom({ ...editingRoom, assignedTeacher: e.target.value })}
                  className="w-full bg-[#141a24] border border-[#222c3d] rounded p-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#1c2434]">
                <button
                  type="button"
                  onClick={() => setEditingRoom(null)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded cursor-pointer"
                >
                  Update Classroom
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Classroom Modal */}
      {viewingRoom && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#111620] border border-[#212b3e] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2434]">
              <div>
                <h3 className="text-base font-bold text-slate-100">{viewingRoom.classroomName}</h3>
                <span className="text-xs font-mono text-cyan-400">{viewingRoom.classroomId}</span>
              </div>
              <button onClick={() => setViewingRoom(null)} className="text-slate-400 hover:text-slate-200 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                <span className="text-slate-400 text-[10px]">LOCATION</span>
                <div className="text-slate-200 mt-0.5">{viewingRoom.building} · {viewingRoom.floor}</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                  <span className="text-slate-400 text-[10px]">CAPACITY</span>
                  <div className="text-slate-100 font-mono font-bold mt-0.5">{viewingRoom.capacity} Students</div>
                </div>
                <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                  <span className="text-slate-400 text-[10px]">GRID DIMENSIONS</span>
                  <div className="text-slate-100 font-mono font-bold mt-0.5">{viewingRoom.rows} Rows × {viewingRoom.columns} Cols</div>
                </div>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                <span className="text-slate-400 text-[10px]">CAMERA CONFIGURATION</span>
                <div className="text-teal-400 font-mono font-semibold mt-0.5">{viewingRoom.cameraType}</div>
                <div className="text-[11px] text-rose-400 mt-0.5">Status: {viewingRoom.cameraStatus}</div>
              </div>

              <div className="p-3 bg-[#131822] border border-[#1e2738] rounded">
                <span className="text-slate-400 text-[10px]">ASSIGNED TEACHER</span>
                <div className="text-slate-200 mt-0.5">{viewingRoom.assignedTeacher}</div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#1c2434]">
              <button
                onClick={() => setViewingRoom(null)}
                className="px-4 py-1.5 bg-[#1a2332] hover:bg-[#202b3d] text-slate-200 text-xs rounded cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
