import React from 'react';
import { 
  Users, 
  Smartphone, 
  Building2, 
  Activity, 
  ArrowRight, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Info,
  Grid3X3,
  ScanEye,
  FileSpreadsheet,
  VideoOff
} from 'lucide-react';
import { PageType, Student, DetectionRecord } from '../types';

interface DashboardPageProps {
  onNavigate: (page: PageType) => void;
  students: Student[];
  records: DetectionRecord[];
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onNavigate,
  students,
  records,
}) => {
  // Prototype values specified in prompt:
  const totalStudents = 60;
  const presentStudents = 56;
  const mobileDetectionEvents = 8;
  const activeClassroom = 'CSE-A';

  // Calculate Behaviour Summary
  const normalCount = students.filter(s => s.status === 'Normal').length;
  const focusedCount = students.filter(s => s.status === 'Focused').length;
  const mobileCount = students.filter(s => s.status === 'Mobile Usage').length;
  const otherCount = students.filter(s => s.status === 'Other').length;
  const totalTracked = students.length || 1;

  const normalPct = Math.round((normalCount / totalTracked) * 100);
  const focusedPct = Math.round((focusedCount / totalTracked) * 100);
  const mobilePct = Math.round((mobileCount / totalTracked) * 100);
  const otherPct = Math.round((otherCount / totalTracked) * 100);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Page Title & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Teacher Classroom Dashboard</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Active Lecture: <span className="text-teal-400 font-medium">CSE-A</span> · Computing Sciences Block · 2nd Floor
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('detection')}
            className="px-3.5 py-1.5 bg-[#14262c] text-teal-300 border border-teal-500/50 hover:bg-[#183139] rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ScanEye className="w-3.5 h-3.5" />
            <span>Detection View</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Prototype Status Disclaimer */}
      <div className="p-3 bg-[#111822] border border-[#1e2a3c] rounded text-xs text-slate-400 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200">Prototype Demo Mode:</strong> Values and incident classifications shown on this dashboard are simulated demo records. Camera hardware is not connected and AI models are under active development.
        </div>
      </div>

      {/* Top 4 KPI Cards: Total Students, Present Students, Mobile Detection Events, Active Classroom */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Total Students */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Students</span>
            <Users className="w-4 h-4 text-teal-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{totalStudents}</span>
            <span className="text-[11px] text-teal-400 font-medium">Enrolled</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Registered cohort for Section CSE-A
          </p>
          <div className="mt-2 pt-2 border-t border-[#18202e] text-[10px] text-slate-400 font-mono">
            Demo Prototype Capacity: 60
          </div>
        </div>

        {/* KPI 2: Present Students */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Present Students</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{presentStudents}</span>
            <span className="text-[11px] text-emerald-400 font-medium">93.3% Attending</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            4 Students absent or unassigned
          </p>
          <div className="mt-2 pt-2 border-t border-[#18202e] text-[10px] text-slate-400 font-mono">
            Active Desks Verified
          </div>
        </div>

        {/* KPI 3: Mobile Detection Events */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Mobile Detection Events</span>
            <Smartphone className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-100">{mobileDetectionEvents}</span>
            <span className="text-[11px] text-amber-400 font-medium">Logged (Demo)</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Downward phone gaze events
          </p>
          <div className="mt-2 pt-2 border-t border-[#18202e] text-[10px] text-slate-400 font-mono">
            Requires Teacher Notice
          </div>
        </div>

        {/* KPI 4: Active Classroom */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Classroom</span>
            <Building2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-slate-100">{activeClassroom}</span>
            <span className="text-[11px] text-cyan-400 font-medium">Active Room</span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Computing Sciences Block · Floor 2
          </p>
          <div className="mt-2 pt-2 border-t border-[#18202e] text-[10px] text-slate-400 font-mono">
            Optical Source: Laptop Webcam
          </div>
        </div>
      </div>

      {/* Main Grid: Recent Detection Events Table + Behaviour Summary & Classroom Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Detection Events Table */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
              <div>
                <h2 className="text-sm font-semibold text-slate-200">Recent Detection Events</h2>
                <p className="text-xs text-slate-400">Chronological telemetry log for active classroom session</p>
              </div>
              <button
                onClick={() => onNavigate('detection')}
                className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Live Feed</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#131822] text-slate-400 uppercase text-[10px] font-mono">
                  <tr>
                    <th className="py-2.5 px-3">Time</th>
                    <th className="py-2.5 px-3">Student ID</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">Seat</th>
                    <th className="py-2.5 px-3">Detection Type</th>
                    <th className="py-2.5 px-3">Behaviour</th>
                    <th className="py-2.5 px-3">Confidence</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#18202e] text-slate-300">
                  {records.slice(0, 5).map((rec) => (
                    <tr key={rec.id} className="hover:bg-[#131823] transition-colors">
                      <td className="py-3 px-3 font-mono text-slate-400 text-[11px] whitespace-nowrap">
                        {rec.time}
                      </td>
                      <td className="py-3 px-3 font-mono text-cyan-400 font-medium">
                        {rec.studentId}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-200">
                        {rec.studentName}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-300">
                        {rec.seat}
                      </td>
                      <td className="py-3 px-3">
                        <span className="text-slate-300 font-medium">
                          {rec.detectionType}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          rec.behaviour === 'Mobile Usage'
                            ? 'bg-amber-950/70 text-amber-300 border border-amber-800/50'
                            : rec.behaviour === 'Focused'
                              ? 'bg-teal-950/70 text-teal-300 border border-teal-800/50'
                              : 'bg-slate-800 text-slate-300'
                        }`}>
                          {rec.behaviour}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-300">
                        {rec.confidence}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                          rec.status === 'Flagged'
                            ? 'bg-rose-950/60 text-rose-300 border border-rose-800/40'
                            : rec.status === 'Reviewed'
                              ? 'bg-teal-950/60 text-teal-300 border border-teal-800/40'
                              : 'bg-slate-800 text-slate-400'
                        }`}>
                          {rec.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Actions Panel */}
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-3">
            <h2 className="text-sm font-semibold text-slate-200">Quick Actions</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <button
                onClick={() => onNavigate('students')}
                className="p-3 bg-[#131922] hover:bg-[#182230] border border-[#1f293b] rounded text-left transition-colors cursor-pointer group"
              >
                <Users className="w-4 h-4 text-emerald-400 mb-1.5 group-hover:scale-110 transition-transform" />
                <div className="font-semibold text-slate-200">Manage Students</div>
                <div className="text-[10px] text-slate-400">Roster & Records</div>
              </button>

              <button
                onClick={() => onNavigate('classroom')}
                className="p-3 bg-[#131922] hover:bg-[#182230] border border-[#1f293b] rounded text-left transition-colors cursor-pointer group"
              >
                <Grid3X3 className="w-4 h-4 text-cyan-400 mb-1.5 group-hover:scale-110 transition-transform" />
                <div className="font-semibold text-slate-200">Open Classroom</div>
                <div className="text-[10px] text-slate-400">Seat Map S01-S20</div>
              </button>

              <button
                onClick={() => onNavigate('detection')}
                className="p-3 bg-[#131922] hover:bg-[#182230] border border-[#1f293b] rounded text-left transition-colors cursor-pointer group"
              >
                <ScanEye className="w-4 h-4 text-teal-400 mb-1.5 group-hover:scale-110 transition-transform" />
                <div className="font-semibold text-slate-200">Start Detection</div>
                <div className="text-[10px] text-slate-400">Laptop Webcam Area</div>
              </button>

              <button
                onClick={() => onNavigate('reports')}
                className="p-3 bg-[#131922] hover:bg-[#182230] border border-[#1f293b] rounded text-left transition-colors cursor-pointer group"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-400 mb-1.5 group-hover:scale-110 transition-transform" />
                <div className="font-semibold text-slate-200">View Reports</div>
                <div className="text-[10px] text-slate-400">Analytics & Export</div>
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Behaviour Summary & Classroom Status */}
        <div className="space-y-6">
          {/* Behaviour Summary Section */}
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
              <h2 className="text-sm font-semibold text-slate-200">Behaviour Summary</h2>
              <span className="text-[10px] font-mono text-teal-400 px-2 py-0.5 bg-[#122026] rounded border border-teal-800/40">
                CSE-A
              </span>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Focused</span>
                  <span className="font-mono text-teal-400 font-semibold">{focusedPct}% ({focusedCount})</span>
                </div>
                <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                  <div className="bg-teal-500 h-full rounded-full" style={{ width: `${focusedPct}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Normal</span>
                  <span className="font-mono text-emerald-400 font-semibold">{normalPct}% ({normalCount})</span>
                </div>
                <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${normalPct}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Mobile Usage</span>
                  <span className="font-mono text-amber-400 font-semibold">{mobilePct}% ({mobileCount})</span>
                </div>
                <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: `${mobilePct}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Other (Postural / Drowsy)</span>
                  <span className="font-mono text-rose-400 font-semibold">{otherPct}% ({otherCount})</span>
                </div>
                <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                  <div className="bg-rose-500 h-full rounded-full" style={{ width: `${otherPct}%` }} />
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-[#18202e] text-[11px] text-slate-400">
              Computed over active cohort observation window.
            </div>
          </div>

          {/* Classroom Status Section */}
          <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
              <h2 className="text-sm font-semibold text-slate-200">Classroom Status</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/40">
                PROTOTYPE
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-[#161c28]">
                <span className="text-slate-400">Classroom:</span>
                <span className="text-slate-200 font-bold font-mono">CSE-A</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#161c28]">
                <span className="text-slate-400">Students:</span>
                <span className="text-slate-200 font-mono">60 Enrolled</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#161c28]">
                <span className="text-slate-400">Camera Source:</span>
                <span className="text-teal-400 font-medium">Laptop Webcam</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Camera Status:</span>
                <span className="text-rose-400 font-semibold flex items-center gap-1.5">
                  <VideoOff className="w-3.5 h-3.5" />
                  <span>Not Connected</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
