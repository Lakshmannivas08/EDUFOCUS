import React, { useState } from 'react';
import { 
  Download, 
  FileText, 
  Calendar, 
  BarChart3, 
  Filter, 
  Check, 
  FileSpreadsheet,
  AlertTriangle,
  Smartphone,
  Users,
  Activity
} from 'lucide-react';
import { DetectionRecord } from '../types';

interface ReportsPageProps {
  records: DetectionRecord[];
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ records }) => {
  const [dateFilter, setDateFilter] = useState('all');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [studentFilter, setStudentFilter] = useState('all');
  const [detectionTypeFilter, setDetectionTypeFilter] = useState('all');
  const [reportActionNotice, setReportActionNotice] = useState<string | null>(null);

  // Filtered records
  const filteredRecords = records.filter(rec => {
    const matchesDate = dateFilter === 'all' || rec.date === dateFilter;
    const matchesClass = classroomFilter === 'all' || rec.classroom === classroomFilter;
    const matchesStudent = studentFilter === 'all' || rec.studentId === studentFilter;
    const matchesType = detectionTypeFilter === 'all' || rec.detectionType === detectionTypeFilter;
    return matchesDate && matchesClass && matchesStudent && matchesType;
  });

  // Overview metrics (Demo numbers specified in prompt)
  const totalEvents = 18;
  const mobileEvents = 8;
  const behaviourAlerts = 6;
  const studentsInvolved = 5;

  const handleExport = () => {
    setReportActionNotice('Export Report: Generated edufocus_classroom_analytics.csv (Demo export)');
    setTimeout(() => setReportActionNotice(null), 3000);
  };

  const handleGenerate = () => {
    setReportActionNotice('Generate Report: Academic PDF summary compiled successfully for CSE-A');
    setTimeout(() => setReportActionNotice(null), 3000);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#1b2332]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Reports & Analytics</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Classroom Behavioural Audit · Session History & Quantitative Analytics (Demo Data)
          </p>
        </div>

        {/* Action Buttons: Export Report, Generate Report */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="px-3.5 py-1.5 bg-[#141a24] hover:bg-[#1a2333] border border-[#212b3e] text-slate-200 rounded text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-teal-400" />
            <span>Export Report</span>
          </button>

          <button
            onClick={handleGenerate}
            className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Generate Report</span>
          </button>
        </div>
      </div>

      {reportActionNotice && (
        <div className="p-3 bg-[#112420] border border-teal-500/50 rounded text-xs text-teal-200 flex items-center gap-2">
          <Check className="w-4 h-4 text-teal-400" />
          <span>{reportActionNotice}</span>
        </div>
      )}

      {/* Detection Overview: 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Detection Events</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-slate-100">{totalEvents}</div>
          <div className="mt-1 text-[11px] text-slate-400">Total logged across sessions</div>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Mobile Phone Events</span>
            <Smartphone className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-400">{mobileEvents}</div>
          <div className="mt-1 text-[11px] text-slate-400">Downward phone gaze detected</div>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Behaviour Alerts</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-rose-400">{behaviourAlerts}</div>
          <div className="mt-1 text-[11px] text-slate-400">Postural & drowsiness warnings</div>
        </div>

        <div className="bg-[#10141d] border border-[#1b2332] rounded p-4">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Students Involved</span>
            <Users className="w-4 h-4 text-teal-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-teal-400">{studentsInvolved}</div>
          <div className="mt-1 text-[11px] text-slate-400">Individuals with flagged events</div>
        </div>
      </div>

      {/* Charts Section: Simple CSS/SVG visual charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Detection Events Over Time */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Detection Events Over Time</h2>
            <BarChart3 className="w-4 h-4 text-teal-400" />
          </div>
          
          <div className="h-44 flex items-end justify-between gap-2 pt-6 px-2">
            {[
              { time: '09:00', count: 1 },
              { time: '09:30', count: 3 },
              { time: '10:00', count: 6 },
              { time: '10:30', count: 4 },
              { time: '11:00', count: 2 },
              { time: '11:30', count: 2 },
            ].map((col, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                <span className="text-[10px] font-mono text-slate-400">{col.count}</span>
                <div 
                  className="w-full bg-teal-500/80 hover:bg-teal-400 rounded-t transition-all"
                  style={{ height: `${(col.count / 6) * 100}%` }}
                />
                <span className="text-[9px] font-mono text-slate-400 whitespace-nowrap">{col.time}</span>
              </div>
            ))}
          </div>
          <div className="text-[11px] text-slate-400 text-center">Peak interval: 09:45 - 10:15 AM</div>
        </div>

        {/* Chart 2: Student-wise Detection Count */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Student-wise Detection Count</h2>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-3 pt-2 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Ishaan Verma (STU009)</span>
                <span className="font-mono text-amber-400">4 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '80%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Callum Wright (STU003)</span>
                <span className="font-mono text-amber-400">3 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '60%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Noah Becker (STU014)</span>
                <span className="font-mono text-rose-400">3 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '60%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Lucas Rossi (STU012)</span>
                <span className="font-mono text-teal-400">2 Events</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-teal-500 h-full rounded-full" style={{ width: '40%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Chart 3: Behaviour Distribution */}
        <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#18202e]">
            <h2 className="text-sm font-semibold text-slate-200">Behaviour Distribution</h2>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>

          <div className="space-y-3 pt-2 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Mobile Phone Usage</span>
                <span className="font-mono text-amber-400">44%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '44%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Drowsiness & Head Drop</span>
                <span className="font-mono text-rose-400">28%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '28%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Gaze / Lateral Deviation</span>
                <span className="font-mono text-teal-400">28%</span>
              </div>
              <div className="w-full bg-[#161c28] h-2 rounded-full overflow-hidden">
                <div className="bg-teal-500 h-full rounded-full" style={{ width: '28%' }} />
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-[#131822] border border-[#1c2434] rounded text-[11px] text-slate-400 leading-relaxed">
            Data aggregated across CS402 morning sessions.
          </div>
        </div>
      </div>

      {/* Detection History Table with Filters */}
      <div className="bg-[#10141d] border border-[#1b2332] rounded p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#18202e]">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">Detection History Log</h2>
            <p className="text-xs text-slate-400">Filtered behavioural observations</p>
          </div>
          <span className="text-[11px] font-mono text-slate-400">{filteredRecords.length} Records Shown</span>
        </div>

        {/* Filters Bar: Date, Classroom, Student, Detection Type */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-[#131822] p-3 rounded border border-[#1d2638]">
          <div>
            <label className="block text-slate-400 mb-1">Date</label>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2.5 py-1.5 rounded outline-none"
            >
              <option value="all">All Dates</option>
              <option value="2026-10-07">2026-10-07 (Today)</option>
              <option value="2026-10-06">2026-10-06</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Classroom</label>
            <select
              value={classroomFilter}
              onChange={(e) => setClassroomFilter(e.target.value)}
              className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2.5 py-1.5 rounded outline-none"
            >
              <option value="all">All Classrooms</option>
              <option value="CSE-A">CSE-A</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Student</label>
            <select
              value={studentFilter}
              onChange={(e) => setStudentFilter(e.target.value)}
              className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2.5 py-1.5 rounded outline-none"
            >
              <option value="all">All Students</option>
              <option value="STU009">Ishaan Verma (STU009)</option>
              <option value="STU003">Callum Wright (STU003)</option>
              <option value="STU014">Noah Becker (STU014)</option>
              <option value="STU012">Lucas Rossi (STU012)</option>
              <option value="STU017">Quinn Gallagher (STU017)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Detection Type</label>
            <select
              value={detectionTypeFilter}
              onChange={(e) => setDetectionTypeFilter(e.target.value)}
              className="w-full bg-[#161e2a] border border-[#232f42] text-slate-200 px-2.5 py-1.5 rounded outline-none"
            >
              <option value="all">All Detection Types</option>
              <option value="Mobile Phone">Mobile Phone</option>
              <option value="Drowsiness">Drowsiness</option>
              <option value="Posture Alert">Posture Alert</option>
              <option value="Gaze Deviation">Gaze Deviation</option>
            </select>
          </div>
        </div>

        {/* Table: Date, Time, Student, Seat, Detection Type, Behaviour, Confidence */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#131822] text-slate-400 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Student</th>
                <th className="py-2.5 px-3">Seat</th>
                <th className="py-2.5 px-3">Detection Type</th>
                <th className="py-2.5 px-3">Behaviour</th>
                <th className="py-2.5 px-3 text-right">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18202e] text-slate-300">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No detection history matches the selected filters.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-[#131823]">
                    <td className="py-2.5 px-3 font-mono text-slate-400">{rec.date}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-400">{rec.time}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-200">
                      {rec.studentName} <span className="text-[10px] font-mono text-cyan-400">({rec.studentId})</span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-300">{rec.seat}</td>
                    <td className="py-2.5 px-3 font-medium">{rec.detectionType}</td>
                    <td className="py-2.5 px-3">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        rec.behaviour === 'Mobile Usage'
                          ? 'bg-amber-950/70 text-amber-300 border border-amber-800/40'
                          : rec.behaviour === 'Focused'
                            ? 'bg-teal-950/70 text-teal-300 border border-teal-800/40'
                            : 'bg-slate-800 text-slate-300'
                      }`}>
                        {rec.behaviour}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-teal-400">{rec.confidence}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
