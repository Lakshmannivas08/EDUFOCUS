export type PageType = 
  | 'login'
  | 'dashboard'
  // Teacher views
  | 'students'
  | 'classroom'
  | 'detection'
  | 'reports'
  | 'settings'
  // Admin views
  | 'teachers'
  | 'classrooms'
  | 'detection-records'
  | 'system-settings';

export type UserRole = 'teacher' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  avatarInitials: string;
}

export type StudentStatus = 'Normal' | 'Focused' | 'Mobile Usage' | 'Other' | 'Absent';

export interface Student {
  id: string;
  studentId: string; // e.g. STU001
  registerNumber: string; // e.g. 717822P101
  name: string;
  email: string;
  assignedSeat: string; // e.g. S01, S05
  classroom: string; // e.g. CSE-A
  status: StudentStatus;
  detectionCount: number;
  notes?: string;
  // Backwards compatibility helpers
  rollNo?: string;
  seatId?: string;
}

export interface DetectionRecord {
  id: string; // e.g. DET-1001
  date: string;
  time: string;
  studentId: string;
  studentName: string;
  seat: string;
  classroom: string;
  detectionType: 'Mobile Phone' | 'Posture Alert' | 'Drowsiness' | 'Gaze Deviation';
  behaviour: 'Normal' | 'Focused' | 'Mobile Usage' | 'Other';
  confidence: string; // e.g. "94%"
  status: 'Flagged' | 'Reviewed' | 'Dismissed';
  source: string; // "Laptop Webcam"
}

export interface TeacherMember {
  id: string;
  empId: string; // Teacher ID, e.g. TCH001
  name: string;
  email: string;
  department: string;
  assignedClassroom: string; // e.g. CSE-A
  status: 'Active' | 'In Session' | 'On Leave';
}

export interface ClassroomRoom {
  id: string;
  classroomId: string; // e.g. CLS001
  classroomName: string; // e.g. CSE-A
  building: string;
  floor: string;
  capacity: number;
  rows: number;
  columns: number;
  assignedTeacher: string;
  studentsCount: number;
  cameraType: 'Laptop Webcam' | 'External Webcam' | 'CCTV / IP Camera';
  cameraStatus: 'Not Connected' | 'Connected' | 'Standby';
}

export interface SystemActivity {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  type: 'session_start' | 'alert' | 'calibration' | 'user_add';
}
