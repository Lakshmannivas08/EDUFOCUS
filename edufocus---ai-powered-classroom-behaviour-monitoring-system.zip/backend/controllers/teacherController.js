const mongoose = require('mongoose');
const Teacher = require('../models/Teacher');

// Local fallback store if MongoDB is not running yet
let memoryTeachers = [
  {
    teacherId: 'TCH001',
    name: 'Dr. Aris Vance',
    email: 'teacher@edufocus.local',
    department: 'Computer Science & Engineering',
    assignedClassroom: 'CSE-A',
    status: 'In Session',
    createdAt: new Date().toISOString()
  },
  {
    teacherId: 'TCH002',
    name: 'Prof. Elena Rostova',
    email: 'e.rostova@edufocus.local',
    department: 'Robotics & Automation',
    assignedClassroom: 'ECE-B',
    status: 'Active',
    createdAt: new Date().toISOString()
  },
  {
    teacherId: 'TCH003',
    name: 'Dr. Marcus Thorne',
    email: 'm.thorne@edufocus.local',
    department: 'Electrical & Electronics',
    assignedClassroom: 'MECH-C',
    status: 'Active',
    createdAt: new Date().toISOString()
  },
  {
    teacherId: 'TCH004',
    name: 'Dr. Alistair Chen',
    email: 'a.chen@edufocus.local',
    department: 'Artificial Intelligence & Data Science',
    assignedClassroom: 'CSE-B',
    status: 'On Leave',
    createdAt: new Date().toISOString()
  }
];

const isDbConnected = () => mongoose.connection.readyState === 1;

exports.getTeachers = async (req, res) => {
  try {
    if (isDbConnected()) {
      const count = await Teacher.countDocuments();
      if (count === 0 && memoryTeachers.length > 0) {
        await Teacher.insertMany(memoryTeachers);
      }
      const teachers = await Teacher.find().sort({ createdAt: -1 });
      return res.status(200).json({ success: true, data: teachers, source: 'mongodb' });
    }
    return res.status(200).json({ success: true, data: memoryTeachers, source: 'fallback_store' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getTeacherById = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const teacher = await Teacher.findOne({ teacherId: id }) || await Teacher.findById(id);
      if (!teacher) return res.status(404).json({ success: false, message: 'Teacher not found' });
      return res.status(200).json({ success: true, data: teacher });
    }
    const teacher = memoryTeachers.find(t => t.teacherId === id || t.id === id);
    if (!teacher) return res.status(404).json({ success: false, message: 'Teacher not found' });
    return res.status(200).json({ success: true, data: teacher });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.createTeacher = async (req, res) => {
  try {
    const { teacherId, name, email, department, assignedClassroom, status } = req.body;
    if (!teacherId || !name || !email || !department) {
      return res.status(400).json({ success: false, message: 'teacherId, name, email, and department are required' });
    }

    if (isDbConnected()) {
      const existing = await Teacher.findOne({ teacherId });
      if (existing) {
        return res.status(400).json({ success: false, message: 'Teacher with this ID already exists' });
      }
      const newTeacher = await Teacher.create({
        teacherId,
        name,
        email,
        department,
        assignedClassroom: assignedClassroom || '',
        status: status || 'Active',
      });
      return res.status(201).json({ success: true, data: newTeacher });
    }

    const exists = memoryTeachers.some(t => t.teacherId === teacherId);
    if (exists) {
      return res.status(400).json({ success: false, message: 'Teacher with this ID already exists' });
    }
    const newTeacher = {
      id: `tch-${Date.now()}`,
      teacherId,
      name,
      email,
      department,
      assignedClassroom: assignedClassroom || '',
      status: status || 'Active',
      createdAt: new Date().toISOString()
    };
    memoryTeachers.unshift(newTeacher);
    return res.status(201).json({ success: true, data: newTeacher });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateTeacher = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const updated = await Teacher.findOneAndUpdate(
        { $or: [{ teacherId: id }, { _id: mongoose.isValidObjectId(id) ? id : null }] },
        req.body,
        { new: true }
      );
      if (!updated) return res.status(404).json({ success: false, message: 'Teacher not found' });
      return res.status(200).json({ success: true, data: updated });
    }

    const idx = memoryTeachers.findIndex(t => t.teacherId === id || t.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Teacher not found' });
    memoryTeachers[idx] = { ...memoryTeachers[idx], ...req.body };
    return res.status(200).json({ success: true, data: memoryTeachers[idx] });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteTeacher = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const deleted = await Teacher.findOneAndDelete({
        $or: [{ teacherId: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!deleted) return res.status(404).json({ success: false, message: 'Teacher not found' });
      return res.status(200).json({ success: true, message: 'Teacher removed successfully' });
    }

    const idx = memoryTeachers.findIndex(t => t.teacherId === id || t.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Teacher not found' });
    memoryTeachers.splice(idx, 1);
    return res.status(200).json({ success: true, message: 'Teacher removed successfully' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
