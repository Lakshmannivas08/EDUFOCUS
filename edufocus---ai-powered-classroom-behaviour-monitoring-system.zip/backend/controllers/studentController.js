const mongoose = require('mongoose');
const Student = require('../models/Student');

// Memory fallback store with preloaded student dataset
let memoryStudents = [
  { studentId: 'STU001', registerNumber: '717822P101', name: 'Aarav Sharma', email: 'aarav.s@edufocus.local', seatNumber: 'S01', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU002', registerNumber: '717822P102', name: 'Beatrix Lin', email: 'beatrix.l@edufocus.local', seatNumber: 'S02', classroomId: 'CSE-A', status: 'Normal', detectionCount: 1, createdAt: new Date().toISOString() },
  { studentId: 'STU003', registerNumber: '717822P103', name: 'Callum Wright', email: 'callum.w@edufocus.local', seatNumber: 'S03', classroomId: 'CSE-A', status: 'Mobile Usage', detectionCount: 3, createdAt: new Date().toISOString() },
  { studentId: 'STU004', registerNumber: '717822P104', name: 'Divya Patel', email: 'divya.p@edufocus.local', seatNumber: 'S04', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU005', registerNumber: '717822P105', name: 'Lakshman Nivas', email: 'lakshman.n@edufocus.local', seatNumber: 'S05', classroomId: 'CSE-A', status: 'Normal', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU006', registerNumber: '717822P106', name: 'Fatima Al-Mansoor', email: 'fatima.m@edufocus.local', seatNumber: 'S06', classroomId: 'CSE-A', status: 'Normal', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU007', registerNumber: '717822P107', name: 'Gavin O\'Connor', email: 'gavin.o@edufocus.local', seatNumber: 'S07', classroomId: 'CSE-A', status: 'Focused', detectionCount: 1, createdAt: new Date().toISOString() },
  { studentId: 'STU008', registerNumber: '717822P108', name: 'Hannah Zhao', email: 'hannah.z@edufocus.local', seatNumber: 'S08', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU009', registerNumber: '717822P109', name: 'Ishaan Verma', email: 'ishaan.v@edufocus.local', seatNumber: 'S09', classroomId: 'CSE-A', status: 'Mobile Usage', detectionCount: 4, createdAt: new Date().toISOString() },
  { studentId: 'STU010', registerNumber: '717822P110', name: 'Jonas Richter', email: 'jonas.r@edufocus.local', seatNumber: 'S10', classroomId: 'CSE-A', status: 'Normal', detectionCount: 1, createdAt: new Date().toISOString() },
  { studentId: 'STU011', registerNumber: '717822P111', name: 'Kavya Raman', email: 'kavya.r@edufocus.local', seatNumber: 'S11', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU012', registerNumber: '717822P112', name: 'Lucas Rossi', email: 'lucas.r@edufocus.local', seatNumber: 'S12', classroomId: 'CSE-A', status: 'Other', detectionCount: 2, createdAt: new Date().toISOString() },
  { studentId: 'STU013', registerNumber: '717822P113', name: 'Mira Kowalski', email: 'mira.k@edufocus.local', seatNumber: 'S13', classroomId: 'CSE-A', status: 'Normal', detectionCount: 1, createdAt: new Date().toISOString() },
  { studentId: 'STU014', registerNumber: '717822P114', name: 'Noah Becker', email: 'noah.b@edufocus.local', seatNumber: 'S14', classroomId: 'CSE-A', status: 'Other', detectionCount: 3, createdAt: new Date().toISOString() },
  { studentId: 'STU015', registerNumber: '717822P115', name: 'Olivia Chen', email: 'olivia.c@edufocus.local', seatNumber: 'S15', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU016', registerNumber: '717822P116', name: 'Priya Sundaram', email: 'priya.s@edufocus.local', seatNumber: 'S16', classroomId: 'CSE-A', status: 'Normal', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU017', registerNumber: '717822P117', name: 'Quinn Gallagher', email: 'quinn.g@edufocus.local', seatNumber: 'S17', classroomId: 'CSE-A', status: 'Mobile Usage', detectionCount: 1, createdAt: new Date().toISOString() },
  { studentId: 'STU018', registerNumber: '717822P118', name: 'Rohan Deshmukh', email: 'rohan.d@edufocus.local', seatNumber: 'S18', classroomId: 'CSE-A', status: 'Normal', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU019', registerNumber: '717822P119', name: 'Sofia Morales', email: 'sofia.m@edufocus.local', seatNumber: 'S19', classroomId: 'CSE-A', status: 'Focused', detectionCount: 0, createdAt: new Date().toISOString() },
  { studentId: 'STU020', registerNumber: '717822P120', name: 'Tariq Hassan', email: 'tariq.h@edufocus.local', seatNumber: 'S20', classroomId: 'CSE-A', status: 'Normal', detectionCount: 1, createdAt: new Date().toISOString() }
];

const isDbConnected = () => mongoose.connection.readyState === 1;

exports.getStudents = async (req, res) => {
  try {
    const { classroomId } = req.query;
    if (isDbConnected()) {
      const count = await Student.countDocuments();
      if (count === 0 && memoryStudents.length > 0) {
        await Student.insertMany(memoryStudents);
      }
      const query = classroomId ? { classroomId } : {};
      const students = await Student.find(query).sort({ studentId: 1 });
      return res.status(200).json({ success: true, data: students, source: 'mongodb' });
    }
    const filtered = classroomId 
      ? memoryStudents.filter(s => s.classroomId === classroomId)
      : memoryStudents;
    return res.status(200).json({ success: true, data: filtered, source: 'fallback_store' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getStudentById = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const student = await Student.findOne({ 
        $or: [{ studentId: id }, { registerNumber: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
      return res.status(200).json({ success: true, data: student });
    }
    const student = memoryStudents.find(s => s.studentId === id || s.registerNumber === id || s.id === id);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });
    return res.status(200).json({ success: true, data: student });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.createStudent = async (req, res) => {
  try {
    const { studentId, registerNumber, name, email, profileImage, seatNumber, classroomId, status, detectionCount } = req.body;
    if (!studentId || !registerNumber || !name || !email || !seatNumber || !classroomId) {
      return res.status(400).json({ 
        success: false, 
        message: 'studentId, registerNumber, name, email, seatNumber, and classroomId are required' 
      });
    }

    if (isDbConnected()) {
      const exists = await Student.findOne({ $or: [{ studentId }, { registerNumber }] });
      if (exists) {
        return res.status(400).json({ success: false, message: 'Student with this ID or Register Number already exists' });
      }
      const newStudent = await Student.create({
        studentId,
        registerNumber,
        name,
        email,
        profileImage: profileImage || '',
        seatNumber,
        classroomId,
        status: status || 'Present',
        detectionCount: detectionCount || 0
      });
      return res.status(201).json({ success: true, data: newStudent });
    }

    const exists = memoryStudents.some(s => s.studentId === studentId || s.registerNumber === registerNumber);
    if (exists) {
      return res.status(400).json({ success: false, message: 'Student with this ID or Register Number already exists' });
    }
    const newStudent = {
      id: `stu-${Date.now()}`,
      studentId,
      registerNumber,
      name,
      email,
      profileImage: profileImage || '',
      seatNumber,
      classroomId,
      status: status || 'Present',
      detectionCount: detectionCount || 0,
      createdAt: new Date().toISOString()
    };
    memoryStudents.push(newStudent);
    return res.status(201).json({ success: true, data: newStudent });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateStudent = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const updated = await Student.findOneAndUpdate(
        { $or: [{ studentId: id }, { registerNumber: id }, { _id: mongoose.isValidObjectId(id) ? id : null }] },
        req.body,
        { new: true }
      );
      if (!updated) return res.status(404).json({ success: false, message: 'Student not found' });
      return res.status(200).json({ success: true, data: updated });
    }

    const idx = memoryStudents.findIndex(s => s.studentId === id || s.registerNumber === id || s.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Student not found' });
    memoryStudents[idx] = { ...memoryStudents[idx], ...req.body };
    return res.status(200).json({ success: true, data: memoryStudents[idx] });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteStudent = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const deleted = await Student.findOneAndDelete({
        $or: [{ studentId: id }, { registerNumber: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!deleted) return res.status(404).json({ success: false, message: 'Student not found' });
      return res.status(200).json({ success: true, message: 'Student deleted successfully' });
    }

    const idx = memoryStudents.findIndex(s => s.studentId === id || s.registerNumber === id || s.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Student not found' });
    memoryStudents.splice(idx, 1);
    return res.status(200).json({ success: true, message: 'Student deleted successfully' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
