const mongoose = require('mongoose');
const Classroom = require('../models/Classroom');

let memoryClassrooms = [
  {
    classroomId: 'CLS001',
    classroomName: 'CSE-A',
    building: 'Computing Sciences Block',
    floor: '2nd Floor',
    capacity: 60,
    rows: 4,
    columns: 5,
    cameraType: 'Laptop Webcam',
    cameraStatus: 'Not Connected',
    assignedTeacher: 'Dr. Aris Vance',
    createdAt: new Date().toISOString()
  },
  {
    classroomId: 'CLS002',
    classroomName: 'ECE-B',
    building: 'Electronics Block',
    floor: '1st Floor',
    capacity: 50,
    rows: 4,
    columns: 5,
    cameraType: 'Laptop Webcam',
    cameraStatus: 'Standby',
    assignedTeacher: 'Prof. Elena Rostova',
    createdAt: new Date().toISOString()
  },
  {
    classroomId: 'CLS003',
    classroomName: 'MECH-C',
    building: 'Mechanical Wing',
    floor: 'Ground Floor',
    capacity: 45,
    rows: 3,
    columns: 5,
    cameraType: 'External Webcam',
    cameraStatus: 'Standby',
    assignedTeacher: 'Dr. Marcus Thorne',
    createdAt: new Date().toISOString()
  },
  {
    classroomId: 'CLS004',
    classroomName: 'AUD-1',
    building: 'Central Academic Complex',
    floor: '3rd Floor',
    capacity: 120,
    rows: 6,
    columns: 8,
    cameraType: 'CCTV / IP Camera',
    cameraStatus: 'Connected',
    assignedTeacher: 'Dr. Alistair Chen',
    createdAt: new Date().toISOString()
  }
];

const isDbConnected = () => mongoose.connection.readyState === 1;

exports.getClassrooms = async (req, res) => {
  try {
    if (isDbConnected()) {
      const count = await Classroom.countDocuments();
      if (count === 0 && memoryClassrooms.length > 0) {
        await Classroom.insertMany(memoryClassrooms);
      }
      const classrooms = await Classroom.find().sort({ classroomName: 1 });
      return res.status(200).json({ success: true, data: classrooms, source: 'mongodb' });
    }
    return res.status(200).json({ success: true, data: memoryClassrooms, source: 'fallback_store' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getClassroomById = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const classroom = await Classroom.findOne({
        $or: [{ classroomId: id }, { classroomName: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!classroom) return res.status(404).json({ success: false, message: 'Classroom not found' });
      return res.status(200).json({ success: true, data: classroom });
    }
    const classroom = memoryClassrooms.find(c => c.classroomId === id || c.classroomName === id || c.id === id);
    if (!classroom) return res.status(404).json({ success: false, message: 'Classroom not found' });
    return res.status(200).json({ success: true, data: classroom });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.createClassroom = async (req, res) => {
  try {
    const { classroomId, classroomName, building, floor, capacity, rows, columns, cameraType, cameraStatus, assignedTeacher } = req.body;
    if (!classroomId || !classroomName || !building || !floor || !capacity) {
      return res.status(400).json({ 
        success: false, 
        message: 'classroomId, classroomName, building, floor, and capacity are required' 
      });
    }

    if (isDbConnected()) {
      const exists = await Classroom.findOne({ $or: [{ classroomId }, { classroomName }] });
      if (exists) {
        return res.status(400).json({ success: false, message: 'Classroom with this ID or Name already exists' });
      }
      const newClassroom = await Classroom.create({
        classroomId,
        classroomName,
        building,
        floor,
        capacity: Number(capacity),
        rows: rows ? Number(rows) : 4,
        columns: columns ? Number(columns) : 5,
        cameraType: cameraType || 'Laptop Webcam',
        cameraStatus: cameraStatus || 'Not Connected',
        assignedTeacher: assignedTeacher || '',
      });
      return res.status(201).json({ success: true, data: newClassroom });
    }

    const exists = memoryClassrooms.some(c => c.classroomId === classroomId || c.classroomName === classroomName);
    if (exists) {
      return res.status(400).json({ success: false, message: 'Classroom with this ID or Name already exists' });
    }
    const newClassroom = {
      id: `cls-${Date.now()}`,
      classroomId,
      classroomName,
      building,
      floor,
      capacity: Number(capacity),
      rows: rows ? Number(rows) : 4,
      columns: columns ? Number(columns) : 5,
      cameraType: cameraType || 'Laptop Webcam',
      cameraStatus: cameraStatus || 'Not Connected',
      assignedTeacher: assignedTeacher || '',
      createdAt: new Date().toISOString()
    };
    memoryClassrooms.push(newClassroom);
    return res.status(201).json({ success: true, data: newClassroom });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateClassroom = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const updated = await Classroom.findOneAndUpdate(
        { $or: [{ classroomId: id }, { classroomName: id }, { _id: mongoose.isValidObjectId(id) ? id : null }] },
        req.body,
        { new: true }
      );
      if (!updated) return res.status(404).json({ success: false, message: 'Classroom not found' });
      return res.status(200).json({ success: true, data: updated });
    }

    const idx = memoryClassrooms.findIndex(c => c.classroomId === id || c.classroomName === id || c.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Classroom not found' });
    memoryClassrooms[idx] = { ...memoryClassrooms[idx], ...req.body };
    return res.status(200).json({ success: true, data: memoryClassrooms[idx] });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteClassroom = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const deleted = await Classroom.findOneAndDelete({
        $or: [{ classroomId: id }, { classroomName: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!deleted) return res.status(404).json({ success: false, message: 'Classroom not found' });
      return res.status(200).json({ success: true, message: 'Classroom deleted successfully' });
    }

    const idx = memoryClassrooms.findIndex(c => c.classroomId === id || c.classroomName === id || c.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Classroom not found' });
    memoryClassrooms.splice(idx, 1);
    return res.status(200).json({ success: true, message: 'Classroom deleted successfully' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
