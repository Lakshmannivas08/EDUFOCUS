const mongoose = require('mongoose');
const Detection = require('../models/Detection');

// Prototype demo detection records
let memoryDetections = [
  {
    detectionId: 'DET-1001',
    studentId: 'STU009',
    studentName: 'Ishaan Verma',
    classroomId: 'CSE-A',
    seatNumber: 'S09',
    detectionType: 'Mobile Phone',
    behaviour: 'Mobile Usage',
    detectedAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    confidence: '94%',
    source: 'Laptop Webcam',
  },
  {
    detectionId: 'DET-1002',
    studentId: 'STU003',
    studentName: 'Callum Wright',
    classroomId: 'CSE-A',
    seatNumber: 'S03',
    detectionType: 'Mobile Phone',
    behaviour: 'Mobile Usage',
    detectedAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    confidence: '91%',
    source: 'Laptop Webcam',
  },
  {
    detectionId: 'DET-1003',
    studentId: 'STU014',
    studentName: 'Noah Becker',
    classroomId: 'CSE-A',
    seatNumber: 'S14',
    detectionType: 'Drowsiness',
    behaviour: 'Other',
    detectedAt: new Date(Date.now() - 1000 * 60 * 38).toISOString(),
    confidence: '88%',
    source: 'Laptop Webcam',
  },
  {
    detectionId: 'DET-1004',
    studentId: 'STU017',
    studentName: 'Quinn Gallagher',
    classroomId: 'CSE-A',
    seatNumber: 'S17',
    detectionType: 'Mobile Phone',
    behaviour: 'Mobile Usage',
    detectedAt: new Date(Date.now() - 1000 * 60 * 55).toISOString(),
    confidence: '96%',
    source: 'Laptop Webcam',
  },
  {
    detectionId: 'DET-1005',
    studentId: 'STU012',
    studentName: 'Lucas Rossi',
    classroomId: 'CSE-A',
    seatNumber: 'S12',
    detectionType: 'Gaze Deviation',
    behaviour: 'Other',
    detectedAt: new Date(Date.now() - 1000 * 60 * 70).toISOString(),
    confidence: '82%',
    source: 'Laptop Webcam',
  },
  {
    detectionId: 'DET-1006',
    studentId: 'STU009',
    studentName: 'Ishaan Verma',
    classroomId: 'CSE-A',
    seatNumber: 'S09',
    detectionType: 'Mobile Phone',
    behaviour: 'Mobile Usage',
    detectedAt: new Date(Date.now() - 1000 * 60 * 95).toISOString(),
    confidence: '95%',
    source: 'Laptop Webcam',
  }
];

const isDbConnected = () => mongoose.connection.readyState === 1;

exports.getDetections = async (req, res) => {
  try {
    const { classroomId, studentId, detectionType } = req.query;
    if (isDbConnected()) {
      const count = await Detection.countDocuments();
      if (count === 0 && memoryDetections.length > 0) {
        await Detection.insertMany(memoryDetections);
      }
      const query = {};
      if (classroomId) query.classroomId = classroomId;
      if (studentId) query.studentId = studentId;
      if (detectionType) query.detectionType = detectionType;

      const records = await Detection.find(query).sort({ detectedAt: -1 });
      return res.status(200).json({ success: true, data: records, source: 'mongodb' });
    }

    let results = [...memoryDetections];
    if (classroomId) results = results.filter(r => r.classroomId === classroomId);
    if (studentId) results = results.filter(r => r.studentId === studentId);
    if (detectionType) results = results.filter(r => r.detectionType === detectionType);

    return res.status(200).json({ success: true, data: results, source: 'fallback_store' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getDetectionById = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const rec = await Detection.findOne({
        $or: [{ detectionId: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!rec) return res.status(404).json({ success: false, message: 'Detection record not found' });
      return res.status(200).json({ success: true, data: rec });
    }
    const rec = memoryDetections.find(d => d.detectionId === id || d.id === id);
    if (!rec) return res.status(404).json({ success: false, message: 'Detection record not found' });
    return res.status(200).json({ success: true, data: rec });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.createDetection = async (req, res) => {
  try {
    const { 
      detectionId, 
      studentId, 
      studentName, 
      classroomId, 
      seatNumber, 
      detectionType, 
      behaviour, 
      confidence, 
      source,
      detectedAt
    } = req.body;

    if (!studentId || !studentName || !classroomId || !seatNumber || !detectionType) {
      return res.status(400).json({
        success: false,
        message: 'studentId, studentName, classroomId, seatNumber, and detectionType are required'
      });
    }

    const generatedId = detectionId || `DET-${Date.now()}`;

    if (isDbConnected()) {
      const newRecord = await Detection.create({
        detectionId: generatedId,
        studentId,
        studentName,
        classroomId,
        seatNumber,
        detectionType,
        behaviour: behaviour || 'Other',
        detectedAt: detectedAt || new Date(),
        confidence: confidence || '90%',
        source: source || 'Laptop Webcam',
      });
      return res.status(201).json({ success: true, data: newRecord });
    }

    const newRecord = {
      id: `det-${Date.now()}`,
      detectionId: generatedId,
      studentId,
      studentName,
      classroomId,
      seatNumber,
      detectionType,
      behaviour: behaviour || 'Other',
      detectedAt: detectedAt || new Date().toISOString(),
      confidence: confidence || '90%',
      source: source || 'Laptop Webcam',
    };
    memoryDetections.unshift(newRecord);
    return res.status(201).json({ success: true, data: newRecord });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteDetection = async (req, res) => {
  try {
    const { id } = req.params;
    if (isDbConnected()) {
      const deleted = await Detection.findOneAndDelete({
        $or: [{ detectionId: id }, { _id: mongoose.isValidObjectId(id) ? id : null }]
      });
      if (!deleted) return res.status(404).json({ success: false, message: 'Detection not found' });
      return res.status(200).json({ success: true, message: 'Detection record removed' });
    }

    const idx = memoryDetections.findIndex(d => d.detectionId === id || d.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Detection not found' });
    memoryDetections.splice(idx, 1);
    return res.status(200).json({ success: true, message: 'Detection record removed' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
