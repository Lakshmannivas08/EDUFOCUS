const express = require('express');
const router = express.Router();
const {
  getDetections,
  getDetectionById,
  createDetection,
  deleteDetection
} = require('../controllers/detectionController');

router.get('/', getDetections);
router.get('/:id', getDetectionById);
router.post('/', createDetection);
router.delete('/:id', deleteDetection);

module.exports = router;
