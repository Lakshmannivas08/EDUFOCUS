const mongoose = require('mongoose');

const ClassroomSchema = new mongoose.Schema(
  {
    classroomId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    classroomName: {
      type: String,
      required: true,
      trim: true,
    },
    building: {
      type: String,
      required: true,
      trim: true,
    },
    floor: {
      type: String,
      required: true,
      trim: true,
    },
    capacity: {
      type: Number,
      required: true,
      min: 1,
    },
    rows: {
      type: Number,
      default: 4,
      min: 1,
    },
    columns: {
      type: Number,
      default: 5,
      min: 1,
    },
    cameraType: {
      type: String,
      enum: ['Laptop Webcam', 'External Webcam', 'CCTV / IP Camera'],
      default: 'Laptop Webcam',
    },
    cameraStatus: {
      type: String,
      enum: ['Not Connected', 'Connected', 'Standby'],
      default: 'Not Connected',
    },
    assignedTeacher: {
      type: String,
      default: '',
      trim: true,
    },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' },
  }
);

module.exports = mongoose.model('Classroom', ClassroomSchema);
