const mongoose = require('mongoose');

const DetectionSchema = new mongoose.Schema(
  {
    detectionId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    studentId: {
      type: String,
      required: true,
      trim: true,
    },
    studentName: {
      type: String,
      required: true,
      trim: true,
    },
    classroomId: {
      type: String,
      required: true,
      trim: true,
    },
    seatNumber: {
      type: String,
      required: true,
      trim: true,
    },
    detectionType: {
      type: String,
      enum: ['Mobile Phone', 'Posture Alert', 'Drowsiness', 'Gaze Deviation'],
      required: true,
    },
    behaviour: {
      type: String,
      enum: ['Normal', 'Focused', 'Mobile Usage', 'Other'],
      default: 'Other',
    },
    detectedAt: {
      type: Date,
      default: Date.now,
    },
    confidence: {
      type: String,
      default: '90%',
    },
    source: {
      type: String,
      default: 'Laptop Webcam',
    },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' },
  }
);

module.exports = mongoose.model('Detection', DetectionSchema);
