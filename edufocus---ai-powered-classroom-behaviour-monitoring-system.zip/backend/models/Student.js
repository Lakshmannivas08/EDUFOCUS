const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema(
  {
    studentId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    registerNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    profileImage: {
      type: String,
      default: '',
    },
    seatNumber: {
      type: String,
      required: true,
      trim: true,
    },
    classroomId: {
      type: String,
      required: true,
      trim: true,
    },
    detectionCount: {
      type: Number,
      default: 0,
      min: 0,
    },
    status: {
      type: String,
      enum: ['Present', 'Absent', 'Inactive', 'Normal', 'Focused', 'Mobile Usage', 'Other'],
      default: 'Present',
    },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' },
  }
);

module.exports = mongoose.model('Student', StudentSchema);
