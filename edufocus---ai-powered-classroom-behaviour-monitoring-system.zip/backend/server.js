const path = require('path');
const dotenv = require('dotenv');

// Load environment variables from backend/.env or root .env
dotenv.config({ path: path.resolve(__dirname, '.env') });
dotenv.config({ path: path.resolve(__dirname, '../.env') });

const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const { requestLogger, errorHandler } = require('./middleware');

// Routes
const teacherRoutes = require('./routes/teacherRoutes');
const studentRoutes = require('./routes/studentRoutes');
const classroomRoutes = require('./routes/classroomRoutes');
const detectionRoutes = require('./routes/detectionRoutes');

const app = express();
// Default to 5000 for backend to avoid collision with container port 8080 / Vite dev 3000
const PORT = process.env.BACKEND_PORT || (process.env.PORT && process.env.PORT !== '8080' && process.env.PORT !== '3000' ? process.env.PORT : 5000);

// Connect to MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

// Health check and root diagnostic
app.get('/api/health', (req, res) => {
  const mongoose = require('mongoose');
  const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected / memory_fallback';
  res.status(200).json({
    status: 'ok',
    project: 'EDUFOCUS',
    system: 'AI-Powered Classroom Behaviour Monitoring System',
    timestamp: new Date().toISOString(),
    database: {
      name: 'eduFocusDB',
      status: dbStatus,
      mongoUriConfigured: Boolean(process.env.MONGO_URI),
    },
    version: '1.0.0-prototype'
  });
});

// API Routes
app.use('/api/teachers', teacherRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/classrooms', classroomRoutes);
app.use('/api/detections', detectionRoutes);

// Dashboard summary endpoint
app.get('/api/dashboard/summary', async (req, res) => {
  try {
    const mongoose = require('mongoose');
    const isDb = mongoose.connection.readyState === 1;
    let totalStudents = 60;
    let presentStudents = 56;
    let mobileEvents = 8;
    let activeClassroom = 'CSE-A';
    let totalTeachers = 12;
    let totalClassrooms = 6;

    if (isDb) {
      const Student = require('./models/Student');
      const Detection = require('./models/Detection');
      const Teacher = require('./models/Teacher');
      const Classroom = require('./models/Classroom');
      totalStudents = await Student.countDocuments();
      presentStudents = await Student.countDocuments({ status: { $ne: 'Absent' } });
      mobileEvents = await Detection.countDocuments({ detectionType: 'Mobile Usage' });
      totalTeachers = await Teacher.countDocuments();
      totalClassrooms = await Classroom.countDocuments();
    }

    res.status(200).json({
      success: true,
      source: isDb ? 'mongodb' : 'fallback_store',
      data: {
        totalStudents,
        presentStudents,
        mobileDetectionEvents: mobileEvents,
        activeClassroom,
        totalTeachers,
        totalClassrooms,
        classroomStatus: {
          classroom: activeClassroom,
          capacity: 60,
          cameraSource: 'Laptop Webcam',
          cameraStatus: 'Not Connected'
        }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 404 handler for API routes
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.url}` });
});

// Error handling middleware
app.use(errorHandler);

// Start server when run directly
if (require.main === module) {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n======================================================`);
    console.log(` EDUFOCUS Backend Server Running`);
    console.log(` Port: ${PORT}`);
    console.log(` Target DB: eduFocusDB`);
    console.log(` Health check: http://localhost:${PORT}/api/health`);
    console.log(`======================================================\n`);
  });
}

module.exports = app;
